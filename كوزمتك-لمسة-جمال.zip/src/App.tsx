/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ActiveTab,
  Product,
  Category,
  SaleItem,
  SaleTransaction,
  StoreSettings,
  POSShift
} from "./types";
import {
  seedDatabaseIfEmpty,
  clearDatabase,
  openDB
} from "./database/sqlite";
import {
  getAllProducts,
  saveProduct,
  deleteProduct,
  getProductById,
  getLowStockCount,
  getTotalProductsCount
} from "./database/products";
import {
  getAllCategories,
  saveCategory,
  deleteCategory
} from "./database/categories";
import {
  getAllSales,
  addSaleTransaction,
  getLatestOrderNum,
  deleteSaleTransaction,
  getAllShifts,
  saveShift,
  getActiveShift,
  deleteShift
} from "./database/sales";
import {
  getStoreSettings,
  saveStoreSettings
} from "./database/settings";

import Splash from "./ui/screens/Splash";
import Onboarding from "./ui/screens/Onboarding";
import POSSale from "./ui/screens/POSSale";
import CartSheet from "./components/CartSheet";
import ProductsAdmin from "./ui/screens/ProductsAdmin";
import ProductFormModal from "./components/ProductFormModal";
import CategoriesAdmin from "./ui/screens/CategoriesAdmin";
import SalesHistory from "./components/SalesHistory";
import Reports from "./components/Reports";
import Settings from "./ui/screens/Settings";
import ShiftsAdmin from "./components/ShiftsAdmin";
import Navbar from "./components/Navbar";
import LoginScreen from "./ui/screens/LoginScreen";
import LicenseLockedScreen from "./ui/screens/LicenseLockedScreen";

// Default Category Order and Sorting Helper
export const DEFAULT_CATEGORY_ORDER = [
  "perfumes",
  "skin_care",
  "face_creams",
  "sunscreen",
  "lipsticks",
  "makeup_pencils",
  "mascara",
  "eyeliner",
  "kohl",
  "eyeshadow",
  "foundation",
  "concealer",
  "powder",
  "blusher",
  "contour",
  "highlighter",
  "makeup_fixer",
  "primer",
  "hair_care",
  "shampoo_conditioner",
  "hair_dyes",
  "body_care",
  "deodorants",
  "accessories_tools"
];

export function sortCategories(cats: Category[]): Category[] {
  const orderMap = new Map<string, number>();
  DEFAULT_CATEGORY_ORDER.forEach((id, index) => {
    orderMap.set(id, index);
  });
  
  return [...cats].sort((a, b) => {
    const idxA = orderMap.has(a.id) ? orderMap.get(a.id)! : 9999;
    const idxB = orderMap.has(b.id) ? orderMap.get(b.id)! : 9999;
    
    if (idxA !== idxB) {
      return idxA - idxB;
    }
    return (a.createdAt || 0) - (b.createdAt || 0);
  });
}


import { verifyLicense } from "./services/license-service";

export default function App() {
  // App Lifecycles
  const [splashActive, setSplashActive] = useState(true);
  const [onboardingActive, setOnboardingActive] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>("sale");
  const [settingsSubTab, setSettingsSubTab] = useState<string>("general");

  // License validation state
  const [licenseChecking, setLicenseChecking] = useState(false);
  const [licenseStatus, setLicenseStatus] = useState<{
    isChecked: boolean;
    isValid: boolean;
    message: string;
    cosmeticName: string;
    licenseType?: string;
    expireDate?: string | null;
  }>({
    isChecked: false,
    isValid: true,
    message: "",
    cosmeticName: localStorage.getItem("pos_cosmetic_name") || "كوزمتك لمسة جمال",
    licenseType: "دائم",
    expireDate: null
  });

  const checkLicenseStatus = async (showLoading = false) => {
    if (showLoading) setLicenseChecking(true);
    try {
      const status = await verifyLicense();
      setLicenseStatus({
        isChecked: true,
        isValid: status.isValid,
        message: status.message,
        cosmeticName: status.cosmeticName,
        licenseType: status.licenseType,
        expireDate: status.expireDate,
      });
    } catch (err) {
      console.error("Failed to verify license:", err);
      // Try parsing from cached storage
      let parsedLicense: any = null;
      try {
        const cached = localStorage.getItem("pos_cached_license");
        if (cached) parsedLicense = JSON.parse(cached);
      } catch (e) {}
      
      setLicenseStatus({
        isChecked: true,
        isValid: parsedLicense ? parsedLicense.isValid : true,
        message: parsedLicense ? parsedLicense.message : "فشل التحقق عبر الإنترنت، تم التحميل محلياً.",
        cosmeticName: parsedLicense ? parsedLicense.cosmeticName : (localStorage.getItem("pos_cosmetic_name") || "كوزمتك لمسة جمال"),
        licenseType: parsedLicense ? parsedLicense.licenseType : "دائم",
        expireDate: parsedLicense ? parsedLicense.expireDate : null,
      });
    } finally {
      if (showLoading) setLicenseChecking(false);
    }
  };

  useEffect(() => {
    checkLicenseStatus();
  }, []);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<{ username: string; role: "manager" | "cashier" } | null>(() => {
    try {
      const saved = localStorage.getItem("pos_current_user");
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  const handleLogin = async (username: string, role: "manager" | "cashier") => {
    const userObj = { username, role };
    setCurrentUser(userObj);
    localStorage.setItem("pos_current_user", JSON.stringify(userObj));
    await checkLicenseStatus();
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("pos_current_user");
    localStorage.removeItem("pos_customer_username");
    localStorage.removeItem("pos_activation_code");
    localStorage.removeItem("pos_cosmetic_name");
    localStorage.removeItem("pos_cached_license");
    localStorage.removeItem("pos_cached_customer_creds");
    triggerToast("تم تسجيل الخروج بنجاح!");
    setActiveTab("sale");
    checkLicenseStatus();
  };

  // Core Data Lists
  const [products, setProducts] = useState<Product[]>([]);
  const [productsRevision, setProductsRevision] = useState(0);
  const [lowStockCount, setLowStockCount] = useState(0);
  const [totalProductsCount, setTotalProductsCount] = useState(0);
  const [categories, setCategories] = useState<Category[]>([]);
  const [sales, setSales] = useState<SaleTransaction[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [shifts, setShifts] = useState<POSShift[]>([]);
  const [activeShift, setActiveShift] = useState<POSShift | null>(null);

  // Cart Management
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  // Active Modals & Popups
  const [activeProductForm, setActiveProductForm] = useState<Product | null | undefined>(undefined);
  const [checkoutSuccessInfo, setCheckoutSuccessInfo] = useState<{ orderNum: number; total: number } | null>(null);
  const [toastMessage, setToastMessage] = useState("");

  // Query lowStockCount and totalProductsCount dynamically whenever productsRevision triggers
  useEffect(() => {
    async function updateStats() {
      try {
        const count = await getLowStockCount();
        setLowStockCount(count);
        const totalCount = await getTotalProductsCount();
        setTotalProductsCount(totalCount);
      } catch (err) {
        console.error("Failed to load product stats:", err);
      }
    }
    updateStats();
  }, [productsRevision]);

  // Initialize and load database
  useEffect(() => {
    async function initDB() {
      try {
        const clearedKey = "pos_demo_cleared_v4";
        if (!localStorage.getItem(clearedKey)) {
          try {
            const db = await openDB();
            const tx = db.transaction(["products", "categories", "sales", "shifts"], "readwrite");
            tx.objectStore("products").clear();
            tx.objectStore("categories").clear();
            tx.objectStore("sales").clear();
            tx.objectStore("shifts").clear();
            await new Promise<void>((res, rej) => {
              tx.oncomplete = () => res();
              tx.onerror = () => rej(tx.error);
            });
            localStorage.setItem(clearedKey, "true");
            localStorage.removeItem("beauty_touch_cart");
          } catch (err) {
            console.warn("Failed to auto-clear demo data", err);
          }
        }

        await seedDatabaseIfEmpty();
        setProductsRevision((prev) => prev + 1);

        let loadedCategories = await getAllCategories();

        const defaultCatsInitKey = "pos_default_categories_initialized_v3";
        if (!localStorage.getItem(defaultCatsInitKey)) {
          if (loadedCategories.length === 0) {
            const defaultCats = [
              { id: "perfumes", name: "العطور", icon: "air" },
              { id: "skin_care", name: "العناية بالبشرة", icon: "spa" },
              { id: "face_creams", name: "كريمات الوجه", icon: "clean_hands" },
              { id: "sunscreen", name: "واقي الشمس", icon: "wb_sunny" },
              { id: "lipsticks", name: "أحمر الشفاه", icon: "brush" },
              { id: "makeup_pencils", name: "أقلام المكياج", icon: "brush" },
              { id: "mascara", name: "الماسكارا", icon: "visibility" },
              { id: "eyeliner", name: "الآيلاينر", icon: "remove_red_eye" },
              { id: "kohl", name: "الكحل", icon: "visibility" },
              { id: "eyeshadow", name: "ظلال العيون", icon: "palette" },
              { id: "foundation", name: "كريم الأساس", icon: "face" },
              { id: "concealer", name: "الكونسيلر", icon: "face_retouching_natural" },
              { id: "powder", name: "البودرة", icon: "blur_on" },
              { id: "blusher", name: "البلاشر", icon: "face" },
              { id: "contour", name: "الكونتور", icon: "grid_view" },
              { id: "highlighter", name: "الهايلايتر", icon: "flare" },
              { id: "makeup_fixer", name: "مثبت المكياج", icon: "done_all" },
              { id: "primer", name: "البرايمر", icon: "layers" },
              { id: "hair_care", name: "العناية بالشعر", icon: "content_cut" },
              { id: "shampoo_conditioner", name: "الشامبو والبلسم", icon: "water_drop" },
              { id: "hair_dyes", name: "صبغات الشعر", icon: "color_lens" },
              { id: "body_care", name: "العناية بالجسم", icon: "accessibility" },
              { id: "deodorants", name: "مزيلات العرق", icon: "co2" },
              { id: "accessories_tools", name: "الإكسسوارات وأدوات التجميل", icon: "shopping_bag" }
            ];

            for (const cat of defaultCats) {
              await saveCategory({
                id: cat.id,
                name: cat.name,
                icon: cat.icon,
                createdAt: Date.now()
              });
            }
            loadedCategories = await getAllCategories();
          }
          localStorage.setItem(defaultCatsInitKey, "true");
        }

        const loadedSales = await getAllSales();
        const loadedSettings = await getStoreSettings();
        const loadedShifts = await getAllShifts();
        const loadedActiveShift = await getActiveShift();

        setProducts([]);
        setCategories(sortCategories(loadedCategories));
        setSales(loadedSales);
        setSettings(loadedSettings);
        setShifts(loadedShifts);
        setActiveShift(loadedActiveShift);

        // Restore saved cart
        const savedCart = localStorage.getItem("beauty_touch_cart");
        if (savedCart) {
          try {
            setCart(JSON.parse(savedCart));
          } catch (e) {
            console.error("Failed to restore cart:", e);
          }
        }
      } catch (err) {
        console.error("IndexedDB initialization error:", err);
      }
    }
    initDB();
  }, []);

  // Save cart to local storage whenever it changes
  useEffect(() => {
    if (cart.length > 0) {
      localStorage.setItem("beauty_touch_cart", JSON.stringify(cart));
    } else {
      localStorage.removeItem("beauty_touch_cart");
    }
  }, [cart]);

  const handleSplashFinished = () => {
    setSplashActive(false);
    if (settings && !settings.onboardingCompleted) {
      setOnboardingActive(true);
    }
  };

  const handleOnboardingFinished = async () => {
    if (settings) {
      const updatedSettings = { ...settings, onboardingCompleted: true };
      await saveStoreSettings(updatedSettings);
      setSettings(updatedSettings);
    }
    setOnboardingActive(false);
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    // 1. Check if product is in stock
    const inCartQty = cart.find((item) => item.productId === product.id)?.quantity || 0;
    if (product.quantity <= inCartQty) {
      triggerToast("عذراً، نفد المخزون المتوفر لهذا المنتج!");
      return;
    }

    // 2. Add or increment
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex((item) => item.productId === product.id);
      if (existingIdx > -1) {
        const updated = [...prevCart];
        const newQty = updated[existingIdx].quantity + 1;
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: newQty,
          total: newQty * updated[existingIdx].price
        };
        return updated;
      } else {
        return [
          ...prevCart,
          {
            productId: product.id,
            name: product.name,
            brand: product.brand,
            price: product.price,
            quantity: 1,
            total: product.price
          }
        ];
      }
    });

    triggerToast(`تمت إضافة "${product.name}" إلى السلة`);
  };

  const handleUpdateCartQty = async (productId: string, quantity: number) => {
    const prod = await getProductById(productId);
    if (!prod) return;

    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }

    if (prod.quantity < quantity) {
      triggerToast(`الكمية المطلوبة تتجاوز المخزون المتاح (${prod.quantity} قطعة)`);
      return;
    }

    setCart((prevCart) =>
      prevCart.map((item) =>
        item.productId === productId
          ? { ...item, quantity, total: quantity * item.price }
          : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.productId !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage("");
    }, 2500);
  };

  // Checkout transaction
  const handleCheckout = async (discountVal: number = 0) => {
    if (cart.length === 0) return;

    if (!activeShift) {
      triggerToast("يرجى فتح وردية نقطة البيع أولاً لإصدار الفواتير!");
      setActiveTab("settings");
      setSettingsSubTab("shifts");
      setCartOpen(false);
      return;
    }

    try {
      const latestOrderNum = await getLatestOrderNum();
      const nextOrderNum = latestOrderNum + 1;
      const orderId = `sale_${Date.now()}`;

      const cartTotal = cart.reduce((sum, item) => sum + item.total, 0);
      const finalTotal = Math.max(0, cartTotal - discountVal);

      const newTransaction: SaleTransaction = {
        id: orderId,
        orderNum: nextOrderNum,
        timestamp: Date.now(),
        items: [...cart],
        totalAmount: finalTotal,
        shiftId: activeShift.id
      };

      // Save Transaction in IndexedDB
      await addSaleTransaction(newTransaction);

      // Reload fresh data from DB (updates quantities)
      const updatedSales = await getAllSales();
      const updatedShifts = await getAllShifts();
      const updatedActiveShift = await getActiveShift();
      
      setProducts([]);
      setProductsRevision((prev) => prev + 1);
      setSales(updatedSales);
      setShifts(updatedShifts);
      setActiveShift(updatedActiveShift);

      // Display Success Modal
      setCheckoutSuccessInfo({
        orderNum: nextOrderNum,
        total: finalTotal
      });

      // Clear Cart state
      setCart([]);
      setCartOpen(false);

    } catch (e) {
      console.error("Checkout failed:", e);
      alert("فشلت عملية البيع، يرجى المحاولة لاحقاً.");
    }
  };

  // Shift Handlers
  const handleOpenShift = async (startBalance: number) => {
    const newShift: POSShift = {
      id: `shift_${Date.now()}`,
      startTime: Date.now(),
      startBalance,
      status: "open",
      salesCount: 0,
      salesTotal: 0
    };
    await saveShift(newShift);
    const loadedShifts = await getAllShifts();
    const loadedActiveShift = await getActiveShift();
    setShifts(loadedShifts);
    setActiveShift(loadedActiveShift);
    triggerToast("تم فتح وردية نقطة البيع بنجاح!");
  };

  const handleCloseShift = async (endBalance: number) => {
    if (!activeShift) return;
    
    // Calculate current shift sales stats from current in-memory sales
    const shiftSales = sales.filter((s) => s.shiftId === activeShift.id);
    const salesCount = shiftSales.length;
    const salesTotal = shiftSales.reduce((sum, s) => sum + s.totalAmount, 0);

    const updatedShift: POSShift = {
      ...activeShift,
      endTime: Date.now(),
      endBalance,
      status: "closed",
      salesCount,
      salesTotal
    };

    await saveShift(updatedShift);
    const loadedShifts = await getAllShifts();
    const loadedActiveShift = await getActiveShift();
    setShifts(loadedShifts);
    setActiveShift(loadedActiveShift);
    triggerToast("تم إغلاق الوردية وتسليم الصندوق بنجاح!");
  };

  const handleDeleteShift = async (id: string) => {
    await deleteShift(id);
    const loadedShifts = await getAllShifts();
    const loadedActiveShift = await getActiveShift();
    setShifts(loadedShifts);
    setActiveShift(loadedActiveShift);
    triggerToast("تم حذف سجل الوردية بنجاح!");
  };

  // Delete transaction handler
  const handleDeleteSale = async (id: string) => {
    await deleteSaleTransaction(id);
    const updatedSales = await getAllSales();
    const updatedShifts = await getAllShifts();
    const updatedActiveShift = await getActiveShift();

    setProducts([]);
    setProductsRevision((prev) => prev + 1);
    setSales(updatedSales);
    setShifts(updatedShifts);
    setActiveShift(updatedActiveShift);
    triggerToast("تم حذف الفاتورة وإرجاع المواد إلى المخزن!");
  };

  // Product Operations
  const handleSaveProduct = async (productData: Product) => {
    await saveProduct(productData);
    setProducts([]);
    setProductsRevision((prev) => prev + 1);
    setActiveProductForm(undefined);
    triggerToast("تم حفظ المنتج بنجاح!");
  };

  const handleBulkSaveProducts = async (productsList: Product[]) => {
    try {
      const db = await openDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction("products", "readwrite");
        const store = tx.objectStore("products");
        for (const prod of productsList) {
          store.put(prod);
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      setProducts([]);
      setProductsRevision((prev) => prev + 1);
      triggerToast(`تم توليد ${productsList.length} منتجاً تجريبياً بنجاح!`);
    } catch (err) {
      console.error("Failed to save products in bulk:", err);
      triggerToast("فشل توليد المنتجات التجريبية!");
    }
  };

  const handleDeleteProduct = async (id: string) => {
    await deleteProduct(id);
    setProducts([]);
    setProductsRevision((prev) => prev + 1);
    triggerToast("تم حذف المنتج بنجاح!");
  };

  // Category Operations
  const handleSaveCategory = async (categoryData: Category) => {
    await saveCategory(categoryData);
    const loaded = await getAllCategories();
    setCategories(sortCategories(loaded));
    triggerToast("تم حفظ التصنيف بنجاح!");
  };

  const handleDeleteCategory = async (id: string, replacementCategoryId?: string) => {
    if (replacementCategoryId) {
      try {
        const db = await openDB();
        await new Promise<void>((resolve, reject) => {
          const tx = db.transaction("products", "readwrite");
          const store = tx.objectStore("products");
          const index = store.index("categoryId");
          const request = index.openCursor(IDBKeyRange.only(id));
          
          request.onsuccess = () => {
            const cursor = request.result;
            if (cursor) {
              const prod = cursor.value as Product;
              prod.categoryId = replacementCategoryId;
              cursor.update(prod);
              cursor.continue();
            } else {
              resolve();
            }
          };
          request.onerror = () => reject(request.error);
        });
      } catch (err) {
        console.error("Failed to transfer products during category deletion:", err);
      }
    }

    await deleteCategory(id);
    const loadedCategories = await getAllCategories();
    setCategories(sortCategories(loadedCategories));
    setProducts([]);
    setProductsRevision((prev) => prev + 1);
    triggerToast(replacementCategoryId ? "تم نقل المنتجات وحذف التصنيف بنجاح!" : "تم حذف التصنيف بنجاح!");
  };

  const handleRestoreDefaultCategories = async () => {
    const defaultCats = [
      { id: "perfumes", name: "العطور", icon: "air" },
      { id: "skin_care", name: "العناية بالبشرة", icon: "spa" },
      { id: "face_creams", name: "كريمات الوجه", icon: "clean_hands" },
      { id: "sunscreen", name: "واقي الشمس", icon: "wb_sunny" },
      { id: "lipsticks", name: "أحمر الشفاه", icon: "brush" },
      { id: "makeup_pencils", name: "أقلام المكياج", icon: "brush" },
      { id: "mascara", name: "الماسكارا", icon: "visibility" },
      { id: "eyeliner", name: "الآيلاينر", icon: "remove_red_eye" },
      { id: "kohl", name: "الكحل", icon: "visibility" },
      { id: "eyeshadow", name: "ظلال العيون", icon: "palette" },
      { id: "foundation", name: "كريم الأساس", icon: "face" },
      { id: "concealer", name: "الكونسيلر", icon: "face_retouching_natural" },
      { id: "powder", name: "البودرة", icon: "blur_on" },
      { id: "blusher", name: "البلاشر", icon: "face" },
      { id: "contour", name: "الكونتور", icon: "grid_view" },
      { id: "highlighter", name: "الهايلايتر", icon: "flare" },
      { id: "makeup_fixer", name: "مثبت المكياج", icon: "done_all" },
      { id: "primer", name: "البرايمر", icon: "layers" },
      { id: "hair_care", name: "العناية بالشعر", icon: "content_cut" },
      { id: "shampoo_conditioner", name: "الشامبو والبلسم", icon: "water_drop" },
      { id: "hair_dyes", name: "صبغات الشعر", icon: "color_lens" },
      { id: "body_care", name: "العناية بالجسم", icon: "accessibility" },
      { id: "deodorants", name: "مزيلات العرق", icon: "co2" },
      { id: "accessories_tools", name: "الإكسسوارات وأدوات التجميل", icon: "shopping_bag" }
    ];

    const existingCats = await getAllCategories();
    const existingNames = new Set(existingCats.map((c) => c.name));
    const existingIds = new Set(existingCats.map((c) => c.id));

    let addedCount = 0;
    for (const cat of defaultCats) {
      if (!existingNames.has(cat.name) && !existingIds.has(cat.id)) {
        await saveCategory({
          id: cat.id,
          name: cat.name,
          icon: cat.icon,
          createdAt: Date.now()
        });
        addedCount++;
      }
    }

    localStorage.setItem("pos_default_categories_initialized_v3", "true");

    if (addedCount > 0) {
      const loaded = await getAllCategories();
      setCategories(sortCategories(loaded));
      triggerToast(`تمت استعادة ${addedCount} تصنيفاً افتراضياً بنجاح!`);
    } else {
      triggerToast("جميع التصنيفات الافتراضية موجودة بالفعل!");
    }
  };

  // Global Settings save
  const handleSaveSettings = async (settingsData: StoreSettings) => {
    await saveStoreSettings(settingsData);
    setSettings(settingsData);
  };

  // Complete IndexedDB clear / database reset
  const handleResetDatabase = async () => {
    localStorage.removeItem("pos_default_categories_initialized_v2");
    localStorage.removeItem("pos_default_categories_initialized_v3");
    await clearDatabase();
    const loadedCategories = await getAllCategories();
    const loadedSales = await getAllSales();
    const loadedSettings = await getStoreSettings();

    setProducts([]);
    setProductsRevision((prev) => prev + 1);
    setCategories(sortCategories(loadedCategories));
    setSales(loadedSales);
    setSettings(loadedSettings);
    setCart([]);
    setActiveTab("sale");
  };

  // Main UI routing switcher
  const renderTabContent = () => {
    switch (activeTab) {
      case "sale":
        return (
          <POSSale
            products={products}
            categories={categories}
            cart={cart}
            marketingText={settings?.marketingText || ""}
            onAddToCart={handleAddToCart}
            onToggleCart={() => setCartOpen(true)}
            onToast={triggerToast}
            cosmeticName={licenseStatus.cosmeticName}
            licenseType={licenseStatus.licenseType}
            expireDate={licenseStatus.expireDate}
            productsRevision={productsRevision}
          />
        );
      case "products":
        return (
          <ProductsAdmin
            products={products}
            categories={categories}
            onAddProduct={() => setActiveProductForm(null)}
            onEditProduct={(p) => setActiveProductForm(p)}
            onDeleteProduct={handleDeleteProduct}
            cosmeticName={licenseStatus.cosmeticName}
            productsRevision={productsRevision}
            totalProductsCount={totalProductsCount}
          />
        );
      case "categories":
        return (
          <CategoriesAdmin
            categories={categories}
            products={products}
            onSaveCategory={handleSaveCategory}
            onDeleteCategory={handleDeleteCategory}
            onRestoreDefaultCategories={handleRestoreDefaultCategories}
            cosmeticName={licenseStatus.cosmeticName}
            productsRevision={productsRevision}
          />
        );
      case "history":
        return <SalesHistory sales={sales} onDeleteSale={handleDeleteSale} />;
      case "shifts":
        return (
          <ShiftsAdmin
            shifts={shifts}
            sales={sales}
            activeShift={activeShift}
            onOpenShift={handleOpenShift}
            onCloseShift={handleCloseShift}
            onDeleteShift={handleDeleteShift}
          />
        );
      case "reports":
        return <Reports sales={sales} products={products} productsRevision={productsRevision} />;
      case "settings":
        if (!settings) return null;
        return (
          <Settings
            settings={settings}
            onSaveSettings={handleSaveSettings}
            onResetDatabase={handleResetDatabase}
            shifts={shifts}
            sales={sales}
            activeShift={activeShift}
            onOpenShift={handleOpenShift}
            onCloseShift={handleCloseShift}
            onDeleteShift={handleDeleteShift}
            onDeleteSale={handleDeleteSale}
            products={products}
            categories={categories}
            onBulkSaveProducts={handleBulkSaveProducts}
            productsRevision={productsRevision}
            activeSubTab={settingsSubTab}
            onSubTabChange={setSettingsSubTab}
            onLogout={handleLogout}
            currentUser={currentUser}
            cosmeticName={licenseStatus.cosmeticName}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div id="app-root-container" className="h-full bg-slate-900 flex justify-center items-center">
      
      {/* 
        Android Phone Layout Frame on Desktop/Tablet, taking full viewport on mobile screen.
        This provides a stunning premium aesthetic that feels exactly like a native app.
      */}
      <div
        id="phone-canvas-frame"
        className="relative w-full max-w-lg h-full sm:h-[94vh] sm:rounded-[40px] sm:my-[3vh] overflow-hidden shadow-2xl flex flex-col border border-rose-100/30"
        style={{
          backgroundImage: "url('/src/assets/images/cosmetics_flatlay_bg_1783625363371.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat"
        }}
      >
        {/* Dedicated high-end, clean pastel backdrop matching screenshot exactly */}
        <div className="absolute inset-0 bg-[#FCFAF8] pointer-events-none z-0" />
        
        {/* Top Status Bar Notch Deco for Android on Large Screens */}
        <div className="hidden sm:block absolute top-0 inset-x-0 h-6 bg-white/40 backdrop-blur-md z-40 rounded-t-[40px] border-b border-[#EFE7E9]">
          <div className="flex justify-between items-center px-8 h-full text-[10px] font-bold text-[#7B0F3A] font-mono">
            <span>{licenseStatus.cosmeticName} POS</span>
            <div className="flex items-center gap-1">
              <span className="material-symbols-outlined !text-xs">wifi</span>
              <span className="material-symbols-outlined !text-xs">battery_5_bar</span>
            </div>
          </div>
        </div>

        {/* Content Body Area */}
        <main className="relative z-10 flex-1 flex flex-col overflow-hidden pt-0 sm:pt-6">
          <AnimatePresence mode="wait">
            {splashActive ? (
              <motion.div key="splash" className="flex-1 flex flex-col overflow-hidden">
                <Splash onFinish={handleSplashFinished} />
              </motion.div>
            ) : !licenseStatus.isValid ? (
              <motion.div key="locked" className="flex-1 flex flex-col overflow-hidden">
                <LicenseLockedScreen
                  message={licenseStatus.message}
                  onRetry={() => checkLicenseStatus(true)}
                  isChecking={licenseChecking}
                />
              </motion.div>
            ) : onboardingActive ? (
              <motion.div key="onboarding" className="flex-1 flex flex-col overflow-hidden">
                <Onboarding onComplete={handleOnboardingFinished} />
              </motion.div>
            ) : currentUser === null ? (
              <motion.div key="login" className="flex-1 flex flex-col overflow-hidden">
                <LoginScreen
                  onLogin={handleLogin}
                  onToast={triggerToast}
                />
              </motion.div>
            ) : (
              <motion.div
                key="main-app"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 flex flex-col overflow-hidden"
              >
                {renderTabContent()}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Bottom App Navigation Bar (Only if Splash, license, and Onboarding finished and user is authenticated) */}
        {!splashActive && licenseStatus.isValid && !onboardingActive && currentUser !== null && (
          <Navbar
            activeTab={activeTab}
            onTabChange={(tab) => {
              setActiveTab(tab);
              if (tab === "settings") {
                setSettingsSubTab("general");
              }
              setCartOpen(false); // Close cart drawer on tab switch
            }}
            lowStockCount={lowStockCount}
          />
        )}

        {/* Floating Cart Bottom Drawer Sheet */}
        <CartSheet
          isOpen={cartOpen}
          cart={cart}
          onClose={() => setCartOpen(false)}
          onUpdateQty={handleUpdateCartQty}
          onRemoveItem={handleRemoveCartItem}
          onClearCart={handleClearCart}
          onCheckout={handleCheckout}
        />

        {/* Product Add/Edit Form Modal */}
        <AnimatePresence>
          {activeProductForm !== undefined && (
            <ProductFormModal
              product={activeProductForm}
              categories={categories}
              defaultLowStockThreshold={settings?.defaultLowStockThreshold || 5}
              onClose={() => setActiveProductForm(undefined)}
              onSave={handleSaveProduct}
            />
          )}
        </AnimatePresence>

        {/* Success Transaction Popup / Modal receipt look */}
        <AnimatePresence>
          {checkoutSuccessInfo && (
            <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-xs">
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white rounded-3xl p-6 w-full max-w-xs text-center space-y-4 shadow-2xl border border-slate-100"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center mx-auto shadow-inner animate-bounce">
                  <span className="material-symbols-outlined !text-4xl">check_circle</span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-base font-extrabold text-slate-800">تمت عملية البيع بنجاح!</h4>
                  <p className="text-xs text-slate-400 font-semibold">
                    تم إصدار الفاتورة رقم #{String(checkoutSuccessInfo.orderNum).padStart(4, "0")}
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 font-mono text-center">
                  <span className="text-[10px] text-slate-400 font-bold block mb-0.5">القيمة المقبوضة:</span>
                  <span className="text-base font-black text-rose-500">
                    {(checkoutSuccessInfo.total).toLocaleString("en-US")} د.ع
                  </span>
                </div>

                <button
                  id="btn-checkout-ok"
                  onClick={() => setCheckoutSuccessInfo(null)}
                  className="w-full py-3 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-xs shadow-md shadow-rose-100 transition-colors"
                >
                  موافق، فحص مستمر
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Global Toast Notification */}
        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className="absolute bottom-20 left-4 right-4 z-40 bg-slate-800/95 backdrop-blur-xs text-white px-4 py-3 rounded-2xl text-xs font-bold shadow-xl flex items-center gap-2 border border-slate-700/50"
            >
              <span className="material-symbols-outlined text-rose-400 !text-lg">info</span>
              <span>{toastMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
