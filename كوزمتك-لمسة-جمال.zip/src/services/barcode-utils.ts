/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Normalizes barcode input strings for exact matching.
 * This is extremely robust against common retail environments:
 * 1. Strips leading/trailing spaces and hidden unicode characters (ZWS, etc.).
 * 2. Translates Eastern Arabic (٠١٢٣٤٥٦٧٨٩) and Persian (۰۱۲۳۴۵۶۷۸۹) numbers to Western Arabic (0-9).
 * 3. Translates Arabic keyboard layout characters back to English (handling wedge scanners typed in Arabic layout).
 * 4. Normalizes casing to lowercase for alphanumeric codes.
 */
export function normalizeBarcode(code: string): string {
  if (!code) return "";
  
  // 1. Strip whitespaces, invisible unicode chars
  let cleaned = String(code)
    .trim()
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, "");

  // 2. Map Eastern Arabic and Persian numerals to Western Arabic (0-9)
  cleaned = cleaned
    .replace(/[٠۰]/g, "0")
    .replace(/[١۱]/g, "1")
    .replace(/[٢۲]/g, "2")
    .replace(/[٣۳]/g, "3")
    .replace(/[٤۴]/g, "4")
    .replace(/[٥۵]/g, "5")
    .replace(/[٦۶]/g, "6")
    .replace(/[٧۷]/g, "7")
    .replace(/[٨۸]/g, "8")
    .replace(/[٩۹]/g, "9");

  // 3. Map Arabic keyboard layout characters to English QWERTY equivalents
  const arabicToEnglishMap: Record<string, string> = {
    // Row 1
    'ض': 'q', 'ص': 'w', 'ث': 'e', 'ق': 'r', 'ف': 't', 'غ': 'y', 'ع': 'u', 'ه': 'i', 'خ': 'o', 'ح': 'p', 'ج': '[', 'د': ']',
    // Row 2
    'ش': 'a', 'س': 's', 'ي': 'd', 'ب': 'f', 'ل': 'g', 'ا': 'h', 'ت': 'j', 'ن': 'k', 'م': 'l', 'ك': ';', 'ط': "'",
    // Row 3
    'ئ': 'z', 'ء': 'x', 'ؤ': 'c', 'ر': 'v', 'لا': 'b', 'ى': 'n', 'ة': 'm', 'و': ',', 'ز': '.', 'ظ': '/'
  };

  let mapped = "";
  for (let i = 0; i < cleaned.length; i++) {
    const char = cleaned[i];
    if (arabicToEnglishMap[char] !== undefined) {
      mapped += arabicToEnglishMap[char];
    } else {
      mapped += char;
    }
  }

  return mapped.toLowerCase();
}

/**
 * Compares two barcodes and returns true if they represent the same product.
 * It is robust against:
 * - Differences in leading zeroes (e.g. EAN-13 pre-pending '0' to UPC-A).
 * - Carriage returns or other noise.
 */
export function areBarcodesMatching(b1: string, b2: string): boolean {
  const norm1 = normalizeBarcode(b1);
  const norm2 = normalizeBarcode(b2);
  
  if (!norm1 || !norm2) return false;
  if (norm1 === norm2) return true;

  // Compare after stripping leading zeroes
  const strip1 = norm1.replace(/^0+/, "");
  const strip2 = norm2.replace(/^0+/, "");
  
  if (strip1 && strip1 === strip2) return true;

  return false;
}
