/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StoreSettings } from "../types";
import { APP_CONFIG } from "../config";
import { openDB } from "./sqlite";

export async function getStoreSettings(): Promise<StoreSettings> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("settings", "readonly");
    const store = tx.objectStore("settings");
    const request = store.get("store_settings");
    request.onsuccess = () => {
      if (request.result) {
        resolve(request.result as StoreSettings);
      } else {
        const defaultSettings: StoreSettings = {
          defaultLowStockThreshold: APP_CONFIG.defaultLowStockThreshold,
          marketingText: APP_CONFIG.marketingText,
          onboardingCompleted: false
        };
        resolve(defaultSettings);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveStoreSettings(settings: StoreSettings): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("settings", "readwrite");
    const store = tx.objectStore("settings");
    const request = store.put({ key: "store_settings", ...settings });
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}
