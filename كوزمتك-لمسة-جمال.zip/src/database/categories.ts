/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Category } from "../types";
import { openDB } from "./sqlite";

let categoriesCache: Category[] | null = null;

export async function getAllCategories(): Promise<Category[]> {
  if (categoriesCache) {
    return [...categoriesCache];
  }
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("categories", "readonly");
    const store = tx.objectStore("categories");
    const request = store.getAll();
    request.onsuccess = () => {
      categoriesCache = request.result as Category[];
      resolve([...categoriesCache]);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveCategory(category: Category): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("categories", "readwrite");
    const store = tx.objectStore("categories");
    const request = store.put(category);
    request.onsuccess = () => {
      categoriesCache = null; // Invalidate cache
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteCategory(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("categories", "readwrite");
    const store = tx.objectStore("categories");
    const request = store.delete(id);
    request.onsuccess = () => {
      categoriesCache = null; // Invalidate cache
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}
