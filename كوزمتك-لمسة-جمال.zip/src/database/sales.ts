/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SaleTransaction, Product, POSShift } from "../types";
import { openDB } from "./sqlite";

export async function getAllSales(): Promise<SaleTransaction[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("sales", "readonly");
    const store = tx.objectStore("sales");
    const request = store.getAll();
    request.onsuccess = () => {
      const sales = request.result as SaleTransaction[];
      sales.sort((a, b) => b.orderNum - a.orderNum);
      resolve(sales);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function addSaleTransaction(transaction: SaleTransaction): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(["sales", "products"], "readwrite");
    const salesStore = tx.objectStore("sales");
    const productsStore = tx.objectStore("products");

    salesStore.add(transaction);

    for (const item of transaction.items) {
      const getReq = productsStore.get(item.productId);
      getReq.onsuccess = () => {
        const prod = getReq.result as Product;
        if (prod) {
          prod.quantity = Math.max(0, prod.quantity - item.quantity);
          productsStore.put(prod);
        }
      };
    }

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getLatestOrderNum(): Promise<number> {
  const sales = await getAllSales();
  if (sales.length === 0) return 0;
  return Math.max(...sales.map((s) => s.orderNum));
}

export async function deleteSaleTransaction(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(["sales", "products"], "readwrite");
    const salesStore = tx.objectStore("sales");
    const productsStore = tx.objectStore("products");

    const getReq = salesStore.get(id);
    getReq.onsuccess = () => {
      const transaction = getReq.result as SaleTransaction;
      if (transaction) {
        for (const item of transaction.items) {
          const getProdReq = productsStore.get(item.productId);
          getProdReq.onsuccess = () => {
            const prod = getProdReq.result as Product;
            if (prod) {
              prod.quantity = prod.quantity + item.quantity;
              productsStore.put(prod);
            }
          };
        }
        salesStore.delete(id);
      }
    };

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Shifts Operations
export async function getAllShifts(): Promise<POSShift[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("shifts", "readonly");
    const store = tx.objectStore("shifts");
    const request = store.getAll();
    request.onsuccess = () => {
      const shifts = request.result as POSShift[];
      shifts.sort((a, b) => b.startTime - a.startTime);
      resolve(shifts);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveShift(shift: POSShift): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("shifts", "readwrite");
    const store = tx.objectStore("shifts");
    const request = store.put(shift);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getActiveShift(): Promise<POSShift | null> {
  const shifts = await getAllShifts();
  const openShift = shifts.find((s) => s.status === "open");
  return openShift || null;
}

export async function deleteShift(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("shifts", "readwrite");
    const store = tx.objectStore("shifts");
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}
