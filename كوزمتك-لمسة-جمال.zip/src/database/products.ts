/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product } from "../types";
import { openDB } from "./sqlite";
import { normalizeBarcode } from "../services/barcode-utils";

export async function getAllProducts(): Promise<Product[]> {
  // To avoid freezing the main page when opening, we return a smaller default list,
  // or we can load all using a lightweight cursor if required, but the screens
  // themselves will now query dynamically. To maintain compatibility with other pages
  // (like reports or exports) we still support a cursor-based getAll, but we restrict it or optimize it.
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    const index = store.index("createdAt");
    const request = index.openCursor(null, "prev");
    const products: Product[] = [];

    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        products.push(cursor.value as Product);
        // Cap at 1000 for legacy compatibility to prevent memory crashes,
        // since the main components now use paged queries for everything.
        if (products.length >= 1000) {
          resolve(products);
          return;
        }
        cursor.continue();
      } else {
        resolve(products);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getProductsPaged(options: {
  categoryId?: string;
  searchQuery?: string;
  stockFilter?: "all" | "available" | "low_stock" | "out_of_stock";
  offset: number;
  limit: number;
}): Promise<{ products: Product[]; totalCount: number; hasMore: boolean }> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");

    let request: IDBRequest<IDBCursorWithValue | null>;
    const useCategoryIndex = options.categoryId && options.categoryId !== "all";

    if (useCategoryIndex) {
      const index = store.index("categoryId");
      request = index.openCursor(IDBKeyRange.only(options.categoryId), "prev");
    } else {
      const index = store.index("createdAt");
      request = index.openCursor(null, "prev");
    }

    const cleanSearch = options.searchQuery ? options.searchQuery.trim().toLowerCase() : "";
    const normSearch = cleanSearch ? normalizeBarcode(cleanSearch) : "";

    const matchedProducts: Product[] = [];
    let matchCount = 0;
    const offset = options.offset || 0;
    const limit = options.limit || 30;

    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        const prod = cursor.value as Product;

        let matches = true;
        if (!useCategoryIndex && options.categoryId && options.categoryId !== "all") {
          if (prod.categoryId !== options.categoryId) {
            matches = false;
          }
        }

        if (matches && options.stockFilter && options.stockFilter !== "all") {
          const isOutOfStock = prod.quantity <= 0;
          const isLowStock = prod.quantity > 0 && prod.quantity <= prod.lowStockThreshold;

          if (options.stockFilter === "available" && isOutOfStock) {
            matches = false;
          } else if (options.stockFilter === "low_stock" && !isLowStock) {
            matches = false;
          } else if (options.stockFilter === "out_of_stock" && !isOutOfStock) {
            matches = false;
          }
        }

        if (matches && cleanSearch) {
          const nameMatch = prod.name.toLowerCase().includes(cleanSearch);
          const brandMatch = prod.brand.toLowerCase().includes(cleanSearch);
          const descMatch = (prod.description || "").toLowerCase().includes(cleanSearch);

          let barcodeMatch = false;
          if (prod.barcode) {
            const normProdBarcode = normalizeBarcode(prod.barcode);
            barcodeMatch = normProdBarcode.includes(normSearch) || normSearch.includes(normProdBarcode);
            if (!barcodeMatch) {
              const stripProd = normProdBarcode.replace(/^0+/, "");
              const stripSearch = normSearch.replace(/^0+/, "");
              if (stripProd && stripSearch && (stripProd.includes(stripSearch) || stripSearch.includes(stripProd))) {
                barcodeMatch = true;
              }
            }
          }

          if (!nameMatch && !brandMatch && !descMatch && !barcodeMatch) {
            matches = false;
          }
        }

        if (matches) {
          if (matchCount >= offset && matchedProducts.length < limit) {
            matchedProducts.push(prod);
          }
          matchCount++;
        }

        cursor.continue();
      } else {
        resolve({
          products: matchedProducts,
          totalCount: matchCount,
          hasMore: matchCount > offset + limit
        });
      }
    };

    request.onerror = () => reject(request.error);
  });
}

export async function getLowStockCount(): Promise<number> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    let count = 0;
    
    // Scan using the quantity index up to a reasonable limit (e.g. 50) to make it extremely fast
    const index = store.index("quantity");
    const request = index.openCursor(IDBKeyRange.upperBound(50));
    
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        const prod = cursor.value as Product;
        if (prod.quantity <= prod.lowStockThreshold) {
          count++;
        }
        cursor.continue();
      } else {
        resolve(count);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getLowStockProducts(limit = 100): Promise<Product[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    const index = store.index("quantity");
    // Scan lower quantity range first to find low stock items immediately
    const request = index.openCursor(IDBKeyRange.upperBound(100));
    const results: Product[] = [];
    
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        const prod = cursor.value as Product;
        if (prod.quantity <= prod.lowStockThreshold) {
          results.push(prod);
          if (results.length >= limit) {
            resolve(results);
            return;
          }
        }
        cursor.continue();
      } else {
        resolve(results);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getProductById(id: string): Promise<Product | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    const request = store.get(id);
    request.onsuccess = () => resolve((request.result as Product) || null);
    request.onerror = () => reject(request.error);
  });
}

export async function getProductCountForCategory(categoryId: string): Promise<number> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    const index = store.index("categoryId");
    const request = index.count(categoryId);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getTotalProductsCount(): Promise<number> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readonly");
    const store = tx.objectStore("products");
    const request = store.count();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveProduct(product: Product): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readwrite");
    const store = tx.objectStore("products");
    const request = store.put(product);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function deleteProduct(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("products", "readwrite");
    const store = tx.objectStore("products");
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}
