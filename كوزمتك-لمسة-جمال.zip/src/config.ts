/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AppConfig {
  storeName: string;
  storeSubName: string;
  marketingText: string;
  currency: string;
  defaultLowStockThreshold: number;
  contactNumber: string;
  location: string;
}

export const APP_CONFIG: AppConfig = {
  storeName: "كوزمتك لمسة جمال",
  storeSubName: "لمسة جمال تبرز أنوثتك",
  marketingText: "أهلاً بكم في كوزمتك لمسة جمال. نوفر لكم أفخم العطور العالمية ومستحضرات التجميل الأصلية والعناية الفائقة بالبشرة والشعر بأفضل الأسعار.",
  currency: "د.ع",
  defaultLowStockThreshold: 5,
  contactNumber: "07700000000",
  location: "العراق، بغداد"
};

export const INITIAL_CATEGORIES: { id: string; name: string; icon: string }[] = [];

export const INITIAL_PRODUCTS: {
  name: string;
  brand: string;
  categoryId: string;
  price: number;
  quantity: number;
  lowStockThreshold: number;
  description: string;
  image: string;
  barcode: string;
}[] = [];
