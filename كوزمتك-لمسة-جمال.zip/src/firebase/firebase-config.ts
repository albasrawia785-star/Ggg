/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApp, getApps } from "firebase/app";
import { getFirestore, doc, getDocFromServer } from "firebase/firestore";

// ============================================================================
// ⚠️ WARNING FOR NEW CLIENTS / STAGE DEPLOYMENT:
// To set up a new client:
// 1. Create a new Firebase Project.
// 2. Enable Cloud Firestore.
// 3. Create a collection named "license" and a document named "settings" inside it.
// 4. Fill in the client's information (cashierUsername, cashierPassword, cosmeticName, licenseType, etc.)
// 5. Replace this config object with your new client's Firebase Web Config.
// 6. Build the application. No other code changes are needed!
// ============================================================================

const firebaseConfig = {
  apiKey: "AIzaSyDozxel6eMwf4_Y377VfNZ7WOHltXyNors",
  authDomain: "cohesive-bonbon-421722.firebaseapp.com",
  projectId: "cohesive-bonbon-421722",
  storageBucket: "cohesive-bonbon-421722.firebasestorage.app",
  messagingSenderId: "475485328675",
  appId: "1:475485328675:web:43b225b2642ff5a3602896"
};

// Initialize Firebase safely so the application doesn't crash during preview if keys are default or offline
let app;
let db: any = null;
let isFirebaseAvailable = false;

try {
  if (getApps().length === 0) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApp();
  }
  db = getFirestore(app);
  isFirebaseAvailable = true;
  console.log("Firebase initialized successfully.");
} catch (error) {
  console.error("Firebase initialization failed or was bypassed. Running in offline fallback mode:", error);
}

export { db, isFirebaseAvailable };

/**
 * Validates the connection to Firestore to check if the client is online and config is valid.
 */
export async function testConnection(): Promise<boolean> {
  if (!isFirebaseAvailable || !db) return false;
  try {
    // Attempt to test the connection by fetching the master license/settings document
    const testRef = doc(db, "license", "settings");
    await getDocFromServer(testRef);
    return true;
  } catch (error: any) {
    if (error?.message?.includes("client is offline") || error?.code === "unavailable") {
      console.warn("Client is offline. Operating in cache-only mode.");
    } else {
      console.error("Connection validation failed. Check Firebase config.", error);
    }
    return false;
  }
}
