/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { APP_CONFIG } from "../../config";

interface SplashProps {
  onFinish: () => void;
}

export default function Splash({ onFinish }: SplashProps) {
  const [cosmeticName, setCosmeticName] = useState(APP_CONFIG.storeName);

  useEffect(() => {
    const savedName = localStorage.getItem("pos_cosmetic_name");
    if (savedName) {
      setCosmeticName(savedName);
    }

    const timer = setTimeout(() => {
      onFinish();
    }, 2500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div id="splash-container" className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-rose-500 via-rose-600 to-brand-700 text-white p-8">
      {/* Top decorative spacing */}
      <div className="h-10"></div>

      {/* Center logo and text */}
      <div className="flex flex-col items-center justify-center text-center">
        {/* Animated Flower/Lipstick Luxury Cosmetics Symbol */}
        <motion.div
          initial={{ opacity: 0, scale: 0.3 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="relative w-32 h-32 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-md border border-white/20 shadow-2xl mb-6"
        >
          {/* Main Icon */}
          <span className="material-symbols-outlined text-rose-100 !text-6xl animate-pulse">
            spa
          </span>
          <motion.span 
            animate={{ scale: [1.2, 0.8, 1.2], opacity: [0.6, 1, 0.6] }}
            transition={{ repeat: Infinity, duration: 2.5, delay: 0.8 }}
            className="material-symbols-outlined absolute -bottom-1 -left-1 text-rose-200 !text-2xl"
          >
            favorite
          </motion.span>
        </motion.div>

        {/* Brand Name */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-4xl font-extrabold tracking-tight text-white drop-shadow-md"
        >
          {cosmeticName}
        </motion.h1>

        {/* Sub-slogan */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="text-rose-100 font-medium text-lg mt-2"
        >
          {APP_CONFIG.storeSubName}
        </motion.p>
      </div>

      {/* Bottom loading indicator and copy */}
      <div className="w-full max-w-xs flex flex-col items-center gap-4 mb-6">
        {/* Simple elegant progress bar */}
        <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 2.2, ease: "easeInOut" }}
            className="h-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]"
          />
        </div>
        <p className="text-xs text-rose-200 font-light font-mono">
          جارٍ تشغيل النظام أوفلاين...
        </p>
      </div>
    </div>
  );
}
