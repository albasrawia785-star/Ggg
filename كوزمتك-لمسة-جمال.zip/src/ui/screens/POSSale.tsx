/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect, useRef, KeyboardEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LayoutGrid, 
  Sparkles, 
  Scissors, 
  Smile, 
  Wind, 
  Search, 
  X, 
  Plus, 
  ShoppingBag
} from "lucide-react";
import { Product, Category, SaleItem } from "../../types";
import ProductImage from "../../components/ProductImage";
import { APP_CONFIG } from "../../config";
import { getProductsPaged } from "../../database/products";
import { normalizeBarcode } from "../../services/barcode-utils";

interface POSSaleProps {
  products: Product[];
  categories: Category[];
  cart: SaleItem[];
  marketingText: string;
  onAddToCart: (product: Product) => void;
  onToggleCart: () => void;
  onToast?: (msg: string) => void;
  cosmeticName?: string;
  licenseType?: string;
  expireDate?: string | null;
  productsRevision?: number; // Force update when DB changes
}

const ITEMS_PER_PAGE = 30;

function playTick() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const audioCtx = new AudioContextClass();
    
    if (audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => {});
    }

    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(1200, audioCtx.currentTime);
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);

    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + 0.05);
  } catch (e) {
    // Ignore sound failures
  }
}

export default function POSSale({
  products,
  categories,
  cart,
  onAddToCart,
  onToggleCart,
  onToast,
  cosmeticName,
  licenseType,
  expireDate,
  productsRevision = 0
}: POSSaleProps) {
  const [selectedCatId, setSelectedCatId] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  
  // local paginated products states
  const [localProducts, setLocalProducts] = useState<Product[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  const loadMoreRef = useRef<HTMLDivElement>(null);

  // Debounce search query (300ms) to prevent hammering IndexedDB
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => {
      clearTimeout(handler);
    };
  }, [searchQuery]);

  // Load initial products when debounced query, category filter or productsRevision changes
  useEffect(() => {
    let active = true;
    async function loadInitial() {
      setLoading(true);
      try {
        const res = await getProductsPaged({
          categoryId: selectedCatId,
          searchQuery: debouncedQuery,
          offset: 0,
          limit: ITEMS_PER_PAGE
        });
        if (active) {
          setLocalProducts(res.products);
          setTotalCount(res.totalCount);
          setHasMore(res.hasMore);
          setPage(1);
        }
      } catch (err) {
        console.error("Failed to load products in POSSale:", err);
      } finally {
        if (active) setLoading(false);
      }
    }
    loadInitial();
    return () => {
      active = false;
    };
  }, [debouncedQuery, selectedCatId, productsRevision]);

  // Local inventory stock decrement: when checkout completes (cart becomes empty)
  const prevCartRef = useRef(cart);
  useEffect(() => {
    if (cart.length === 0 && prevCartRef.current.length > 0) {
      const soldMap = new Map<string, number>(prevCartRef.current.map((item) => [item.productId, item.quantity]));
      setLocalProducts((prev) => 
        prev.map((prod) => {
          const soldQty = soldMap.get(prod.id);
          if (soldQty !== undefined) {
            return {
              ...prod,
              quantity: Math.max(0, prod.quantity - soldQty)
            };
          }
          return prod;
        })
      );
    }
    prevCartRef.current = cart;
  }, [cart]);

  // Load more on scroll
  const handleLoadMore = async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const nextPage = page + 1;
      const res = await getProductsPaged({
        categoryId: selectedCatId,
        searchQuery: debouncedQuery,
        offset: (nextPage - 1) * ITEMS_PER_PAGE,
        limit: ITEMS_PER_PAGE
      });
      setLocalProducts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const filteredNew = res.products.filter((p) => !existingIds.has(p.id));
        return [...prev, ...filteredNew];
      });
      setTotalCount(res.totalCount);
      setHasMore(res.hasMore);
      setPage(nextPage);
    } catch (err) {
      console.error("Failed to load more products in POSSale:", err);
    } finally {
      setLoading(false);
    }
  };

  // IntersectionObserver for dynamic loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          handleLoadMore();
        }
      },
      { threshold: 0.1 }
    );

    const currentLoadMore = loadMoreRef.current;
    if (currentLoadMore) {
      observer.observe(currentLoadMore);
    }

    return () => {
      if (currentLoadMore) {
        observer.unobserve(currentLoadMore);
      }
    };
  }, [hasMore, loading, page, selectedCatId, debouncedQuery]);

  // Calculate remaining license limit
  const getLicenseRemainingText = () => {
    if (!licenseType) return null;
    if (licenseType === "دائم") {
      return {
        label: "ترخيص دائم",
        color: "bg-emerald-50 text-emerald-700 border-emerald-100",
        icon: "verified"
      };
    }
    if (!expireDate) return null;

    const msDiff = new Date(expireDate).getTime() - Date.now();
    if (msDiff <= 0) {
      return {
        label: "الترخيص منتهي",
        color: "bg-red-50 text-red-600 border-red-100",
        icon: "warning"
      };
    }

    const hours = Math.floor(msDiff / (1000 * 60 * 60));
    if (licenseType === "تجريبي") {
      if (hours < 24) {
        const minutes = Math.floor((msDiff % (1000 * 60 * 60)) / (1000 * 60));
        return {
          label: `متبقي من التجربة: ${hours} س و ${minutes} د`,
          color: "bg-amber-50 text-amber-700 border-amber-200 animate-pulse",
          icon: "hourglass_empty"
        };
      } else {
        const days = Math.floor(hours / 24);
        const remainingHours = hours % 24;
        return {
          label: `متبقي من التجربة: ${days} يوم و ${remainingHours} س`,
          color: "bg-amber-50 text-amber-700 border-amber-200",
          icon: "hourglass_bottom"
        };
      }
    } else if (licenseType === "سنوي") {
      const days = Math.ceil(msDiff / (1000 * 60 * 60 * 24));
      return {
        label: `متبقي من الاشتراك: ${days} يوم`,
        color: "bg-teal-50 text-teal-700 border-teal-100",
        icon: "calendar_today"
      };
    }
    return null;
  };

  const licenseBadge = getLicenseRemainingText();

  // Unlock audio context on first click/touchstart (crucial for iOS Safari / Android Chrome silent policy bypass)
  useEffect(() => {
    const unlockAudio = () => {
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          const audioCtx = new AudioContextClass();
          if (audioCtx.state === "suspended") {
            audioCtx.resume();
          }
          // Play silent buffer to force unlock on mobile Safari
          const buffer = audioCtx.createBuffer(1, 1, 22050);
          const source = audioCtx.createBufferSource();
          source.buffer = buffer;
          source.connect(audioCtx.destination);
          source.start(0);
        }
      } catch (e) {
        console.warn("Audio pre-unlock failed:", e);
      }
      window.removeEventListener("click", unlockAudio);
      window.removeEventListener("touchstart", unlockAudio);
    };
    window.addEventListener("click", unlockAudio);
    window.addEventListener("touchstart", unlockAudio);
    return () => {
      window.removeEventListener("click", unlockAudio);
      window.removeEventListener("touchstart", unlockAudio);
    };
  }, []);

  // Totals
  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const totalCartPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  return (
    <div className="flex flex-col h-full bg-[#FCFAF8] overflow-hidden select-none relative">
      {/* 
        Fixed Premium Header at the top
        Keeping Search Box frozen for fast single-hand thumb operations
      */}
      <div className="bg-[#FCFAF8]/95 backdrop-blur-md px-4 pt-4 pb-3 border-b border-[#EFE7E9] z-20 space-y-3 shrink-0 text-right" dir="rtl">
        <div className="flex justify-between items-center flex-row pb-1">
          <div className="text-right">
            <h2 className="text-sm font-bold text-[#7B0F3A]">{cosmeticName || "كوزمتك لمسة جمال"}</h2>
            <div className="flex items-center gap-1.5 mt-0.5 justify-end">
              {licenseBadge && (
                <span className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[8px] font-black border leading-none ${licenseBadge.color}`}>
                  <span className="material-symbols-outlined !text-[10px]">{licenseBadge.icon}</span>
                  <span>{licenseBadge.label}</span>
                </span>
              )}
              <p className="text-[10px] text-slate-400 font-medium">نظام نقطة البيع المباشر</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-row">
            {/* Connection status (Wifi online) */}
            <div className="flex items-center gap-1 bg-white text-[#7B0F3A] font-bold px-2 py-0.5 rounded-full border border-[#EFE7E9] text-[9px] select-none shadow-3xs">
              <span className="material-symbols-outlined !text-[11px] font-bold">wifi</span>
              <span>متصل</span>
            </div>
            
            {/* Product Count chip */}
            <div className="flex items-center gap-1 bg-[#7B0F3A]/5 text-[#7B0F3A] font-bold px-2 py-0.5 rounded-full border border-[#EFE7E9] text-[9px] select-none shadow-3xs">
              <span>{products.length} منتج</span>
            </div>
          </div>
        </div>

        {/* Big Sticky Search Box & Clear Trigger */}
        <div className="flex gap-2.5 items-center h-[56px]">
          <div id="pos-search-wrapper" className="relative flex-1 h-full">
            <input
              id="pos-search-input"
              type="text"
              placeholder="ابحث عن منتج..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-full pr-11 pl-11 py-3 bg-white border border-[#EFE7E9] rounded-[18px] shadow-3xs text-xs focus:outline-none focus:ring-2 focus:ring-[#7B0F3A]/10 focus:border-[#7B0F3A] transition-all font-bold text-[#252525] placeholder:text-slate-400 text-right"
            />
            <Search className="absolute top-4.5 right-3.5 text-slate-400 w-5 h-5 pointer-events-none" />
            {searchQuery && (
              <button
                id="pos-search-clear"
                onClick={() => setSearchQuery("")}
                className="absolute top-3.5 left-3 text-slate-400 hover:text-slate-600 transition-colors w-7 h-7 flex items-center justify-center rounded-full bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Scrollable Container for lists and sliders */}
      <div className="flex-1 overflow-y-auto px-4 space-y-5 pt-3 pb-28 no-scrollbar">
        {/* Scrollable Categories Slider as Chip Buttons */}
        <div className="space-y-2 text-right">
          <h3 className="text-xs font-bold text-[#7B0F3A] tracking-wide pr-1">التصنيفات</h3>
          <div dir="rtl" className="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 no-scrollbar scroll-smooth">
            {/* 'All' category chip */}
            <button
              id="category-chip-all"
              onClick={() => setSelectedCatId("all")}
              className={`flex items-center justify-center gap-1.5 h-[44px] px-5 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer border ${
                selectedCatId === "all"
                  ? "bg-[#7B0F3A] text-white border-transparent shadow-sm"
                  : "bg-white text-[#252525] border-[#EFE7E9] hover:border-[#7B0F3A]/30"
              }`}
            >
              <span className="material-symbols-outlined !text-[18px]">grid_view</span>
              <span>الكل</span>
            </button>

            {categories.map((cat) => {
              const isSelected = selectedCatId === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`category-chip-${cat.id}`}
                  onClick={() => setSelectedCatId(cat.id)}
                  className={`flex items-center justify-center gap-1.5 h-[44px] px-5 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer border ${
                    isSelected
                      ? "bg-[#7B0F3A] text-white border-transparent shadow-sm"
                      : "bg-white text-[#252525] border-[#EFE7E9] hover:border-[#7B0F3A]/30"
                  }`}
                >
                  <span className="material-symbols-outlined !text-[18px]">{cat.icon || "category"}</span>
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Products List Layout matching mockup */}
        <div className="space-y-3 text-right">
          <div className="flex flex-row justify-between items-center px-1">
            <span className="text-[10px] font-bold text-[#7B0F3A] bg-[#7B0F3A]/5 px-3 py-1 rounded-full border border-[#7B0F3A]/10">
              {totalCount} منتج
            </span>
            <h3 className="text-xs font-bold text-[#7B0F3A] tracking-wide">المنتجات المعروضة</h3>
          </div>

          {localProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center bg-white rounded-2xl border border-[#EFE7E9] p-6">
              <span className="material-symbols-outlined text-slate-300 !text-5xl mb-2">find_in_page</span>
              <p className="text-xs font-bold text-slate-700">لم يتم العثور على نتائج</p>
              <p className="text-[10px] text-slate-400 mt-1">جرب البحث بكلمات أخرى أو تغيير التصنيف.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-2.5">
              <AnimatePresence>
                {localProducts.map((prod) => {
                  const isOutOfStock = prod.quantity <= 0;
                  const isLowStock = prod.quantity > 0 && prod.quantity <= prod.lowStockThreshold;

                  return (
                    <motion.div
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      key={prod.id}
                      id={`product-card-${prod.id}`}
                      onClick={() => {
                        if (!isOutOfStock) {
                          onAddToCart(prod);
                          playTick();
                        }
                      }}
                      className={`flex flex-row items-center justify-between bg-white rounded-[20px] border border-[#EFE7E9] p-4 transition-all h-[124px] relative hover:border-[#7B0F3A]/25 select-none shadow-3xs ${
                        isOutOfStock ? "opacity-60 cursor-not-allowed" : "cursor-pointer active:scale-[0.99]"
                      }`}
                    >
                      {/* Right Side: Product Details & Price / Plus row */}
                      <div className="flex-1 pr-1 pl-4 text-right flex flex-col justify-between h-full min-w-0">
                        {/* Name and Brand */}
                        <div className="space-y-1 pt-1">
                          <h4 className="text-[13px] font-bold text-[#252525] leading-tight break-words">
                            {prod.name}
                          </h4>
                          <p className="text-[10px] text-slate-400 font-medium">{prod.brand}</p>
                        </div>

                        {/* Stock status Chip & Badge & Plus Button Row */}
                        <div className="flex items-center justify-between flex-row">
                          {/* Stock status small Chip */}
                          <div className="flex items-center">
                            {isOutOfStock ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-red-50 text-red-600 border border-red-100">
                                نفد
                              </span>
                            ) : isLowStock ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-50 text-amber-600 border border-amber-100">
                                شبه نافد ({prod.quantity})
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-100">
                                متوفر ({prod.quantity})
                              </span>
                            )}
                          </div>

                          {/* Price Badge & Plus button */}
                          <div className="flex items-center gap-2">
                            {/* Price inside a soft pink Badge */}
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-[#E9CDD7]/45 text-[#7B0F3A] font-mono">
                              {prod.price.toLocaleString("en-US")} د.ع
                            </span>

                            {/* Plus Button - Circular */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (!isOutOfStock) {
                                  onAddToCart(prod);
                                  playTick();
                                }
                              }}
                              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                                isOutOfStock 
                                  ? "bg-slate-100 text-slate-400 cursor-not-allowed" 
                                  : "bg-[#7B0F3A] text-white hover:bg-[#5C0B2B] shadow-sm shadow-[#7B0F3A]/10"
                              }`}
                            >
                              <Plus className="w-4 h-4 stroke-[3]" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Left Side: Large Image */}
                      <div className="relative w-20 h-20 bg-[#FCFAF8] rounded-[16px] overflow-hidden border border-[#EFE7E9] shrink-0 flex items-center justify-center">
                        <ProductImage image={prod.image} categoryId={prod.categoryId} name={prod.name} />
                        {isOutOfStock && (
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white text-[10px] font-extrabold">
                            مباع
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}

          {/* Lazy Load sensor element */}
          {hasMore && (
            <div ref={loadMoreRef} className="flex justify-center py-4">
              <span className="animate-spin material-symbols-outlined text-primary !text-2xl">sync</span>
            </div>
          )}
        </div>
      </div>

      {/* Sticky Bottom Mini Cart Bar */}
      {totalCartCount > 0 && (
        <div className="absolute bottom-[84px] inset-x-4 z-30">
          <motion.button
            id="btn-cart-fab"
            onClick={onToggleCart}
            initial={{ scale: 0.95, y: 15, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 15, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="w-full h-[52px] bg-[#7B0F3A] hover:bg-[#5C0B2B] text-white rounded-[20px] flex items-center justify-between px-4 shadow-md transition-all cursor-pointer select-none active:scale-98"
          >
            {/* Right side: item count & icon */}
            <div className="flex items-center gap-2 flex-row-reverse">
              <span className="text-base">🛒</span>
              <span className="text-xs font-bold text-white">
                {totalCartCount} {totalCartCount === 1 ? "منتج" : totalCartCount > 2 && totalCartCount < 11 ? "منتجات" : "منتج"}
              </span>
            </div>

            {/* Middle: Total Amount */}
            <div className="text-xs font-extrabold text-[#E9CDD7] font-mono">
              <span>{totalCartPrice.toLocaleString("en-US")}</span>
              <span className="text-[10px] font-sans mr-0.5">د.ع</span>
            </div>

            {/* Left side: arrow indicator and button */}
            <div className="flex items-center gap-1 font-bold text-[#E9CDD7] text-xs">
              <span>عرض السلة</span>
              <span className="material-symbols-outlined !text-sm">arrow_back</span>
            </div>
          </motion.button>
        </div>
      )}


    </div>
  );
}
