/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, useEffect } from "react";
import { motion } from "motion/react";
import { Sparkles, Lock, User, Eye, EyeOff } from "lucide-react";
import { loginUser } from "../../services/login-service";

interface LoginScreenProps {
  onLogin: (username: string, role: "manager" | "cashier") => void;
  onToast: (msg: string) => void;
}

export default function LoginScreen({ onLogin, onToast }: LoginScreenProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [cosmeticName, setCosmeticName] = useState("كوزمتك لمسة جمال");

  useEffect(() => {
    // Dynamically read cosmetic name from local storage cached by the licensing service
    const savedName = localStorage.getItem("pos_cosmetic_name");
    if (savedName) {
      setCosmeticName(savedName);
    }
  }, []);

  // Dynamically query Firestore to fetch cosmetic name on username input
  useEffect(() => {
    if (!username) {
      const savedName = localStorage.getItem("pos_cosmetic_name");
      setCosmeticName(savedName || "كوزمتك لمسة جمال");
      return;
    }

    const trimmed = username.trim().toLowerCase();
    if (trimmed === "ali") {
      setCosmeticName("بوابة المدير العام (علي)");
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const { isFirebaseAvailable, db } = await import("../../firebase/firebase-config");
        if (isFirebaseAvailable && db) {
          const { doc, getDoc } = await import("firebase/firestore");
          const docRef = doc(db, "customers", trimmed);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            if (data && data.cosmeticName) {
              setCosmeticName(data.cosmeticName);
            }
          }
        }
      } catch (err) {
        console.warn("Could not fetch cosmetic name online", err);
      }
    }, 400); // 400ms debounce

    return () => clearTimeout(timer);
  }, [username]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    // Call loginUser with optional activation code
    const res = await loginUser(username, password);

    if (res.success && res.user) {
      onLogin(res.user.username, res.user.role);
      onToast(`مرحباً بك، ${res.user.username}!`);
    } else {
      setError(res.error || "فشل تسجيل الدخول");
      onToast("فشل تسجيل الدخول!");
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-center items-center p-6 bg-[#FCFAF8] h-full select-none" dir="rtl">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-sm flex flex-col space-y-8"
      >
        {/* Brand identity - Premium & Minimalist */}
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="w-20 h-20 bg-white border border-[#EFE7E9] rounded-2xl flex items-center justify-center shadow-xs overflow-hidden">
            <img
              src="/src/assets/images/cosmetics_beauty_logo_1783807344564.jpg"
              alt="Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-xl font-extrabold text-[#252525] tracking-tight font-sans">
              {cosmeticName}
            </h1>
            <p className="text-xs text-slate-400 font-semibold tracking-wide">
              نظام نقطة البيع المباشر والمستودع
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 text-right">
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-red-50 border border-red-100 text-red-600 text-xs font-bold py-3 px-4 rounded-xl text-center shadow-3xs"
            >
              {error}
            </motion.div>
          )}

          {/* Username */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 mr-1">اسم المستخدم</label>
            <div className="relative h-14">
              <input
                id="login-username"
                type="text"
                dir="rtl"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="أدخل اسم المستخدم..."
                className="w-full h-full pr-11 pl-4 bg-white border border-[#EFE7E9] rounded-[18px] text-xs font-semibold shadow-2xs focus:outline-none focus:ring-2 focus:ring-[#7B0F3A]/10 focus:border-[#7B0F3A] transition-all text-right text-[#252525]"
              />
              <User className="absolute right-4 top-5 w-4 h-4 text-slate-400" />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 mr-1">كلمة المرور</label>
            <div className="relative h-14">
              <input
                id="login-password"
                type={showPassword ? "text" : "password"}
                dir="rtl"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة المرور..."
                className="w-full h-full pr-11 pl-11 bg-white border border-[#EFE7E9] rounded-[18px] text-xs font-semibold shadow-2xs focus:outline-none focus:ring-2 focus:ring-[#7B0F3A]/10 focus:border-[#7B0F3A] transition-all text-right text-[#252525]"
              />
              <Lock className="absolute right-4 top-5 w-4 h-4 text-slate-400" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-4 top-5 text-slate-400 hover:text-slate-600 focus:outline-none cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            id="btn-submit-login"
            type="submit"
            className="w-full h-14 mt-4 bg-[#7B0F3A] hover:bg-[#5C0B2B] text-white font-bold rounded-[20px] shadow-sm active:scale-98 transition-all text-xs cursor-pointer flex items-center justify-center gap-2"
          >
            تسجيل الدخول
          </button>
        </form>
      </motion.div>
    </div>
  );
}
