/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Plus,
  Trash2,
  Edit2,
  Copy,
  ShieldAlert,
  Key,
  RefreshCw,
  UserCheck,
  UserX,
  Calendar,
  User,
  Phone,
  Store,
  ArrowRight,
  ShieldCheck,
  Clock,
  Check,
  Search
} from "lucide-react";
import {
  Customer,
  getAllCustomers,
  saveCustomer,
  deleteCustomer,
  toggleCustomerStatus,
  updateCustomerLicense,
  resetCustomerPassword,
  generateNewActivationCodeForCustomer,
  generateFourBlockActivationCode
} from "../../services/license-service";

interface CustomersAdminProps {
  onBack: () => void;
}

export default function CustomersAdmin({ onBack }: CustomersAdminProps) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [toastMessage, setToastMessage] = useState("");

  // Modal states
  const [showFormModal, setShowFormModal] = useState(false);
  const [formType, setFormType] = useState<"create" | "edit">("create");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Form Fields
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [cosmeticName, setCosmeticName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [phone, setPhone] = useState("");
  const [licenseType, setLicenseType] = useState<"تجريبي" | "سنوي" | "دائم">("تجريبي");
  const [trialHours, setTrialHours] = useState(24);

  // Password Reset Modal
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [newPassword, setNewPassword] = useState("");

  // Custom confirmation modal states
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3000);
  };

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const data = await getAllCustomers();
      setCustomers(data);
    } catch (err) {
      console.error(err);
      triggerToast("فشل تحميل قائمة العملاء!");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleOpenCreateModal = () => {
    setFormType("create");
    setSelectedCustomer(null);
    setUsername("");
    setPassword("");
    setCosmeticName("");
    setOwnerName("");
    setPhone("");
    setLicenseType("" as any);
    setTrialHours("" as any);
    setShowFormModal(true);
  };

  const handleOpenEditModal = (cust: Customer) => {
    setFormType("edit");
    setSelectedCustomer(cust);
    setUsername(cust.username);
    setPassword(cust.password || "");
    setCosmeticName(cust.cosmeticName);
    setOwnerName(cust.ownerName);
    setPhone(cust.phone);
    setLicenseType(cust.licenseType);
    setTrialHours(cust.trialHours || 0);
    setShowFormModal(true);
  };

  const handleSaveSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username || !cosmeticName) {
      triggerToast("يرجى ملء الحقول المطلوبة!");
      return;
    }
    if (!licenseType) {
      triggerToast("يرجى اختيار نوع الترخيص!");
      return;
    }
    if (licenseType === "تجريبي" && (!trialHours || Number(trialHours) <= 0)) {
      triggerToast("يرجى إدخال عدد ساعات التجربة الصالحة!");
      return;
    }

    try {
      if (formType === "create") {
        // Double check username is unique in locally loaded list
        const exists = customers.some(c => c.username.toLowerCase() === username.trim().toLowerCase());
        if (exists) {
          triggerToast("اسم المستخدم هذا محجوز مسبقاً!");
          return;
        }

        const actCode = generateFourBlockActivationCode();
        const now = new Date();
        let expDate: string | null = null;

        if (licenseType === "تجريبي") {
          expDate = new Date(now.getTime() + Number(trialHours) * 3600 * 1000).toISOString();
        } else if (licenseType === "سنوي") {
          expDate = new Date(now.getTime() + 365 * 24 * 3600 * 1000).toISOString();
        }

        const newCust: Customer = {
          username: username.trim().toLowerCase(),
          password: password.trim() || "1234",
          activationCode: actCode,
          cosmeticName: cosmeticName.trim(),
          ownerName: ownerName.trim(),
          phone: phone.trim(),
          licenseType,
          trialHours: licenseType === "تجريبي" ? Number(trialHours) : 0,
          expireDate: expDate,
          status: "active",
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        };

        await saveCustomer(newCust);
        setShowFormModal(false);
        triggerToast("تم إنشاء العميل بنجاح!");
      } else {
        // Edit existing
        if (!selectedCustomer) return;
        const now = new Date();
        let expDate = selectedCustomer.expireDate;

        // Recalculate expiration only if license type changed
        if (licenseType !== selectedCustomer.licenseType) {
          if (licenseType === "تجريبي") {
            expDate = new Date(now.getTime() + Number(trialHours) * 3600 * 1000).toISOString();
          } else if (licenseType === "سنوي") {
            expDate = new Date(now.getTime() + 365 * 24 * 3600 * 1000).toISOString();
          } else {
            expDate = null;
          }
        }

        const updatedCust: Customer = {
          ...selectedCustomer,
          cosmeticName: cosmeticName.trim(),
          ownerName: ownerName.trim(),
          phone: phone.trim(),
          licenseType,
          trialHours: licenseType === "تجريبي" ? trialHours : 0,
          expireDate: expDate,
          updatedAt: now.toISOString()
        };

        await saveCustomer(updatedCust);
        setShowFormModal(false);
        triggerToast("تم تعديل بيانات العميل بنجاح!");
      }
      loadCustomers();
    } catch (err) {
      console.error(err);
      triggerToast("حدث خطأ أثناء الحفظ!");
    }
  };

  const handleDelete = async (cust: Customer) => {
    setCustomerToDelete(cust);
  };

  const executeDelete = async () => {
    if (!customerToDelete) return;
    try {
      await deleteCustomer(customerToDelete.username);
      triggerToast("تم حذف العميل بنجاح!");
      setCustomerToDelete(null);
      loadCustomers();
    } catch (err) {
      console.error(err);
      triggerToast("فشل الحذف!");
    }
  };

  const handleToggleStatus = async (cust: Customer) => {
    try {
      await toggleCustomerStatus(cust.username, cust.status);
      triggerToast(cust.status === "active" ? "تم إيقاف الترخيص بنجاح!" : "تم تفعيل الترخيص بنجاح!");
      loadCustomers();
    } catch (err) {
      console.error(err);
      triggerToast("فشل تعديل حالة الترخيص!");
    }
  };

  const handleSetLicenseType = async (cust: Customer, type: "تجريبي" | "سنوي" | "دائم") => {
    try {
      const hours = type === "تجريبي" ? 24 : undefined;
      await updateCustomerLicense(cust.username, type, hours);
      triggerToast(`تم تحويل الترخيص إلى ${type} بنجاح!`);
      loadCustomers();
    } catch (err) {
      console.error(err);
      triggerToast("فشل تحديث فئة الترخيص!");
    }
  };



  const handleOpenPasswordModal = (cust: Customer) => {
    setSelectedCustomer(cust);
    setNewPassword("");
    setShowPasswordModal(true);
  };

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || !newPassword) return;
    try {
      await resetCustomerPassword(selectedCustomer.username, newPassword);
      setShowPasswordModal(false);
      triggerToast("تمت إعادة تعيين كلمة المرور بنجاح!");
      loadCustomers();
    } catch (err) {
      console.error(err);
      triggerToast("فشل تغيير كلمة المرور!");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    triggerToast("تم نسخ الكود إلى الحافظة!");
  };

  const filteredCustomers = customers.filter(c => 
    c.cosmeticName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.ownerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16 text-right font-sans" dir="rtl">
      {/* Header Panel */}
      <div className="p-4 bg-white border-b border-slate-100 shrink-0 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold transition-all cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>رجوع للإعدادات</span>
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-800">إدارة العملاء والتراخيص</h2>
          <p className="text-xs text-slate-400 font-medium">إنشاء وإدارة حسابات العملاء وتراخيص التشغيل السحابية</p>
        </div>
      </div>

      {/* Control Bar */}
      <div className="p-4 bg-slate-50 border-b border-slate-100 shrink-0 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            placeholder="بحث باسم الكوزمتك، المستخدم، المالك..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-xs font-semibold text-right text-slate-800 bg-white"
          />
          <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-400" />
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="w-full sm:w-auto px-4 py-2.5 bg-primary hover:bg-primary-dark text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-primary/10 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة عميل جديد</span>
        </button>
      </div>

      {/* Main Grid View */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar bg-slate-50/50">
        {toastMessage && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-slate-900 text-white text-xs font-bold rounded-full shadow-lg flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <RefreshCw className="w-8 h-8 text-primary animate-spin" />
            <p className="text-xs text-slate-400 font-bold">جاري تحميل العملاء والبيانات...</p>
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="text-center py-20 bg-white border border-slate-100 rounded-3xl space-y-3">
            <div className="w-12 h-12 bg-slate-50 text-slate-400 flex items-center justify-center rounded-2xl mx-auto">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-700">لا يوجد عملاء مطابقين للبحث</p>
              <p className="text-[11px] text-slate-400 mt-0.5">أضف عميلاً جديداً للبدء في تفعيل التراخيص</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredCustomers.map((cust) => {
              const isExpired = cust.expireDate && new Date(cust.expireDate).getTime() < Date.now();
              const isSuspended = cust.status === "suspended";

              return (
                <motion.div
                  key={cust.username}
                  layout
                  className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs flex flex-col justify-between space-y-4 relative overflow-hidden hover:shadow-md transition-all"
                >
                  {/* Status Indicator Bar */}
                  <div className={`absolute top-0 inset-x-0 h-1.5 ${isSuspended ? "bg-red-500" : isExpired ? "bg-amber-500" : "bg-emerald-500"}`} />

                  {/* Header info */}
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-1">
                      {/* License Badge */}
                      <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black ${
                        cust.licenseType === "دائم" ? "bg-indigo-50 text-indigo-600 border border-indigo-100" :
                        cust.licenseType === "سنوي" ? "bg-teal-50 text-teal-600 border border-teal-100" :
                        "bg-pink-50 text-pink-600 border border-pink-100"
                      }`}>
                        {cust.licenseType}
                      </span>

                      {/* Status Badge */}
                      <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black ${
                        isSuspended ? "bg-red-50 text-red-600 border border-red-100" :
                        isExpired ? "bg-amber-50 text-amber-600 border border-amber-100" :
                        "bg-emerald-50 text-emerald-600 border border-emerald-100"
                      }`}>
                        {isSuspended ? "موقوف" : isExpired ? "منتهي" : "نشط"}
                      </span>
                    </div>

                    <div className="text-right">
                      <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5 justify-end">
                        <span>{cust.cosmeticName}</span>
                        <Store className="w-4 h-4 text-primary" />
                      </h3>
                      <p className="text-[10px] text-slate-400 font-mono font-bold mt-0.5">@{cust.username}</p>
                    </div>
                  </div>

                  {/* Body fields */}
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100 text-xs font-medium text-slate-600">
                    <div className="space-y-1 text-right">
                      <p className="text-[10px] text-slate-400">اسم المالك</p>
                      <p className="text-slate-700 font-bold truncate flex items-center justify-end gap-1">
                        <span>{cust.ownerName || "غير محدد"}</span>
                        <User className="w-3 h-3 text-slate-400" />
                      </p>
                    </div>
                    <div className="space-y-1 text-right">
                      <p className="text-[10px] text-slate-400">رقم الهاتف</p>
                      <p className="text-slate-700 font-bold truncate font-mono flex items-center justify-end gap-1">
                        <span>{cust.phone || "غير محدد"}</span>
                        <Phone className="w-3 h-3 text-slate-400" />
                      </p>
                    </div>

                    <div className="space-y-1 text-right col-span-2">
                      <p className="text-[10px] text-slate-400">تاريخ انتهاء الترخيص</p>
                      <p className="text-slate-700 font-bold flex items-center justify-end gap-1">
                        <span>{cust.licenseType === "دائم" ? "لا ينتهي (ترخيص دائم)" : cust.expireDate ? new Date(cust.expireDate).toLocaleDateString("ar-EG") + " " + new Date(cust.expireDate).toLocaleTimeString("ar-EG", {hour: '2-digit', minute:'2-digit'}) : "غير محدد"}</span>
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      </p>
                    </div>
                  </div>

                  {/* Actions Grid */}
                  <div className="pt-3 border-t border-slate-100 flex flex-wrap gap-2 justify-end">
                    {/* Enable/Disable status */}
                    <button
                      onClick={() => handleToggleStatus(cust)}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 border cursor-pointer transition-colors ${
                        isSuspended
                          ? "bg-emerald-50 border-emerald-100 text-emerald-600 hover:bg-emerald-100"
                          : "bg-red-50 border-red-100 text-red-600 hover:bg-red-100"
                      }`}
                    >
                      {isSuspended ? <UserCheck className="w-3 h-3" /> : <UserX className="w-3 h-3" />}
                      <span>{isSuspended ? "تفعيل" : "إيقاف الترخيص"}</span>
                    </button>

                    {/* Reset Password */}
                    <button
                      onClick={() => handleOpenPasswordModal(cust)}
                      className="px-2 py-1 rounded-lg text-[10px] font-bold border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Key className="w-3 h-3" />
                      <span>كلمة المرور</span>
                    </button>

                    {/* Edit info */}
                    <button
                      onClick={() => handleOpenEditModal(cust)}
                      className="px-2 py-1 rounded-lg text-[10px] font-bold border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>تعديل</span>
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => handleDelete(cust)}
                      className="px-2 py-1 rounded-lg text-[10px] font-bold bg-danger/5 border border-danger/10 text-danger hover:bg-danger/10 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف</span>
                    </button>
                  </div>

                  {/* Fast Conversion Actions */}
                  <div className="pt-2 border-t border-slate-100/50 flex gap-1 justify-end flex-wrap">
                    <span className="text-[8px] text-slate-400 ml-1 self-center">تحويل الفئة:</span>
                    {cust.licenseType !== "دائم" && (
                      <button
                        onClick={() => handleSetLicenseType(cust, "دائم")}
                        className="px-1.5 py-0.5 rounded-md text-[8px] font-extrabold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors"
                      >
                        دائم
                      </button>
                    )}
                    {cust.licenseType !== "سنوي" && (
                      <button
                        onClick={() => handleSetLicenseType(cust, "سنوي")}
                        className="px-1.5 py-0.5 rounded-md text-[8px] font-extrabold bg-teal-50 hover:bg-teal-100 text-teal-700 transition-colors"
                      >
                        سنوي
                      </button>
                    )}
                    {cust.licenseType !== "تجريبي" && (
                      <button
                        onClick={() => handleSetLicenseType(cust, "تجريبي")}
                        className="px-1.5 py-0.5 rounded-md text-[8px] font-extrabold bg-pink-50 hover:bg-pink-100 text-pink-700 transition-colors"
                      >
                        تجريبي
                      </button>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL 1: Create or Edit Customer */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[32px] p-6 w-full max-w-md shadow-xl text-right space-y-4 border border-slate-100 max-h-[90vh] overflow-y-auto no-scrollbar"
            >
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <button
                  onClick={() => setShowFormModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  إغلاق
                </button>
                <h3 className="font-extrabold text-slate-800 text-base">
                  {formType === "create" ? "إضافة عميل جديد" : "تعديل بيانات العميل"}
                </h3>
              </div>

              <form onSubmit={handleSaveSubmit} className="space-y-4">
                {/* Username */}
                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">اسم المستخدم (يستخدم لتسجيل الدخول)</label>
                  <input
                    type="text"
                    required
                    disabled={formType === "edit"}
                    value={username}
                    onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, ""))}
                    placeholder="مثال: jamil_cosmetic"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800 disabled:bg-slate-50"
                  />
                </div>

                {/* Password */}
                {formType === "create" && (
                  <div className="space-y-1 text-right">
                    <label className="block text-xs font-bold text-slate-500">كلمة المرور الافتراضية</label>
                    <input
                      type="text"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="أدخل الباسورد للعميل..."
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800"
                    />
                  </div>
                )}

                {/* Cosmetic Name */}
                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">اسم الكوزمتك (المعرض في التطبيق والفاتورة)</label>
                  <input
                    type="text"
                    required
                    value={cosmeticName}
                    onChange={(e) => setCosmeticName(e.target.value)}
                    placeholder="مثال: كوزمتك لمسة جمال"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800"
                  />
                </div>

                {/* Owner Name */}
                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">اسم المالك</label>
                  <input
                    type="text"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    placeholder="مثال: علي محمد"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800"
                  />
                </div>

                {/* Phone */}
                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">رقم الهاتف</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="مثال: 07701234567"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800 font-mono"
                  />
                </div>

                {/* License Type */}
                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">نوع الترخيص</label>
                  <select
                    value={licenseType || ""}
                    onChange={(e) => setLicenseType(e.target.value as any)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800 bg-white"
                  >
                    <option value="">-- اختر نوع الترخيص --</option>
                    <option value="تجريبي">تجريبي (ساعات محددة)</option>
                    <option value="سنوي">سنوي (365 يوم)</option>
                    <option value="دائم">دائم (لا ينتهي)</option>
                  </select>
                </div>

                {/* Trial Hours */}
                {licenseType === "تجريبي" && (
                  <div className="space-y-1 text-right">
                    <label className="block text-xs font-bold text-slate-500">مدة التجربة (بالساعات)</label>
                    <input
                      type="number"
                      value={trialHours || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "") {
                          setTrialHours("" as any);
                        } else {
                          setTrialHours(Math.max(1, Number(val)));
                        }
                      }}
                      placeholder="أدخل عدد الساعات..."
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3 bg-primary hover:bg-primary-dark text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
                >
                  {formType === "create" ? "إنشاء عميل جديد" : "حفظ التعديلات"}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>



      {/* MODAL 3: Reset Password */}
      <AnimatePresence>
        {showPasswordModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[32px] p-6 w-full max-w-sm shadow-xl text-right space-y-4 border border-slate-100"
            >
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  إلغاء
                </button>
                <h4 className="font-extrabold text-slate-800">إعادة تعيين كلمة المرور</h4>
              </div>

              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <div className="space-y-1 text-right">
                  <p className="text-xs text-slate-400">إعادة تعيين الباسورد للعميل:</p>
                  <p className="text-xs font-bold text-slate-700">@{selectedCustomer?.username}</p>
                </div>

                <div className="space-y-1 text-right">
                  <label className="block text-xs font-bold text-slate-500">كلمة المرور الجديدة</label>
                  <input
                    type="text"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="أدخل كلمة المرور الجديدة..."
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-right text-slate-800"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-primary hover:bg-primary-dark text-white font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  تغيير وحفظ الباسورد
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CUSTOM MODAL: Customer Delete Confirmation */}
      <AnimatePresence>
        {customerToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setCustomerToDelete(null)}></div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[32px] p-6 w-full max-w-sm shadow-2xl relative flex flex-col z-10 border border-slate-100 text-center space-y-4"
            >
              <div className="w-14 h-14 bg-rose-50 text-rose-500 flex items-center justify-center rounded-full mx-auto">
                <Trash2 className="w-7 h-7" />
              </div>
              <div>
                <h4 className="font-extrabold text-slate-800 text-base">حذف حساب العميل؟</h4>
                <p className="text-xs text-slate-400 mt-2 font-medium leading-relaxed">
                  هل أنت متأكد من رغبتك في حذف حساب العميل <span className="font-bold text-slate-700">"{customerToDelete.cosmeticName}"</span> نهائياً؟ لا يمكن التراجع عن هذا الإجراء وسيتوقف الترخيص فوراً.
                </p>
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  id="btn-confirm-delete-cust-yes"
                  onClick={executeDelete}
                  className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all cursor-pointer shadow-md shadow-rose-100"
                >
                  نعم، احذف العميل
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete-cust-no"
                  onClick={() => setCustomerToDelete(null)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>


    </div>
  );
}
