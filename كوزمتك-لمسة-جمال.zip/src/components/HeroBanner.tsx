/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import cosmeticsBanner from "../assets/images/cosmetics_banner_1783638454087.jpg";

export default function HeroBanner() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      id="hero-banner"
      className="relative overflow-hidden rounded-[36px] bg-white border border-[#EAD3CD]/30 shadow-xs p-5 flex flex-col justify-between h-56"
    >
      {/* Background Image of Cosmetics occupying the FULL width of the card */}
      <div 
        className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat rounded-[36px] z-0"
        style={{
          backgroundImage: `url(${cosmeticsBanner})`,
        }}
      />
      
      {/* Premium linear gradient overlay transitioning from soft rose on the right to highly readable solid cream on the left */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#FAF4F2] via-[#FAF4F2]/90 to-[#FAF4F2]/30 pointer-events-none z-10" />

      {/* Decorative radial lighting flare */}
      <div className="absolute -top-12 left-12 w-32 h-32 bg-pink-100/35 rounded-full blur-3xl pointer-events-none z-10"></div>

      {/* Top Header Row within the Banner Card */}
      <div className="relative z-20 flex justify-between items-center w-full">
        {/* Left: Bell Icon with active red badge */}
        <div className="relative cursor-pointer hover:scale-105 active:scale-95 transition-all w-9 h-9 rounded-full bg-[#FAF2F0] border border-[#EAD3CD]/40 flex items-center justify-center text-[#800F35]">
          <span className="material-symbols-outlined !text-xl font-black">notifications</span>
          <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-[#D12B47] rounded-full ring-2 ring-white animate-pulse"></span>
        </div>

        {/* Right: Online Badge Pill with Wi-Fi icon */}
        <div className="flex items-center gap-1.5 bg-[#FAF0F1] text-[#800F35] font-black px-4 py-1.5 rounded-full border border-[#D5A18E]/30 text-[10px] shadow-2xs select-none">
          <span className="material-symbols-outlined !text-xs font-black">wifi</span>
          <span>نسخة الأونلاين</span>
        </div>
      </div>

      {/* Title & Slogan on the Left (aligned text-right for beautiful Arabic presentation) */}
      <div className="relative z-20 text-right w-[50%] flex flex-col justify-end mt-auto pl-1">
        <h2 className="text-[22px] font-black leading-tight text-[#5C0620] tracking-tight">
          كوزمتك لمسة
          <br />
          جمال
        </h2>
        <p className="text-[10px] text-[#800F35] font-black tracking-wide mt-1.5">
          لمسة جمال تبرز أنوثتك
        </p>
      </div>
    </motion.div>
  );
}
