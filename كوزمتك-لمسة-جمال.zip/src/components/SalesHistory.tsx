/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { SaleTransaction } from "../types";
import { APP_CONFIG } from "../config";

interface SalesHistoryProps {
  sales: SaleTransaction[];
  onDeleteSale?: (id: string) => void;
  onBack?: () => void;
}

export default function SalesHistory({ sales, onDeleteSale, onBack }: SalesHistoryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSale, setSelectedSale] = useState<SaleTransaction | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [saleToDelete, setSaleToDelete] = useState<SaleTransaction | null>(null);

  useEffect(() => {
    setShowDeleteConfirm(false);
  }, [selectedSale]);

  // Filter sales based on order num or item names
  const filteredSales = useMemo(() => {
    return sales.filter((sale) => {
      const orderNumStr = `#${String(sale.orderNum).padStart(4, "0")}`;
      const matchesOrderNum = orderNumStr.includes(searchQuery);
      
      const matchesItems = sale.items.some(
        (item) =>
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.brand.toLowerCase().includes(searchQuery.toLowerCase())
      );

      return matchesOrderNum || matchesItems;
    });
  }, [sales, searchQuery]);

  const formatPrice = (price: number) => {
    return price.toLocaleString("en-US") + " " + APP_CONFIG.currency;
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString("ar-IQ", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16">
      {/* Search & Header Panel */}
      <div className="p-4 bg-white border-b border-slate-100 space-y-4">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="w-10 h-10 rounded-full bg-rose-50 hover:bg-rose-100 active:scale-95 text-[#800F35] flex items-center justify-center transition-all cursor-pointer border border-rose-100/30"
              title="رجوع"
            >
              <span className="material-symbols-outlined font-black">arrow_forward</span>
            </button>
          )}
          <div className="flex-1 text-right">
            <h2 className="text-xl font-bold text-slate-800">سجل المبيعات والفواتير</h2>
            <p className="text-xs text-slate-400 font-medium">عرض فواتير المبيعات الصادرة أوفلاين</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            id="history-search-input"
            type="text"
            placeholder="البحث برقم الفاتورة (مثال: #0001) أو اسم المنتج..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-11 pl-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all font-medium text-slate-800"
          />
          <span className="material-symbols-outlined absolute top-3 right-4 text-slate-400 !text-xl pointer-events-none">
            receipt_long
          </span>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute top-3 left-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <span className="material-symbols-outlined !text-base">close</span>
            </button>
          )}
        </div>
      </div>

      {/* Transactions List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
        {filteredSales.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="material-symbols-outlined text-slate-300 !text-6xl mb-2">history</span>
            <p className="text-sm font-bold text-slate-600">لا توجد عمليات بيع مسجلة</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
              قم بإجراء أول عملية بيع من واجهة البيع لحفظ السجل وعرض تفاصيل المبيعات اليومية هنا.
            </p>
          </div>
        ) : (
          filteredSales.map((sale) => {
            const formattedId = `#${String(sale.orderNum).padStart(4, "0")}`;
            const totalItems = sale.items.reduce((acc, it) => acc + it.quantity, 0);

            return (
              <div
                key={sale.id}
                id={`sale-transaction-${sale.id}`}
                onClick={() => setSelectedSale(sale)}
                className="bg-white rounded-2xl border border-slate-100 shadow-xs p-4 flex items-center justify-between gap-4 cursor-pointer hover:border-rose-200 transition-all active:scale-[0.99]"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-800 font-mono">{formattedId}</span>
                    <span className="text-[10px] bg-rose-50 text-rose-600 font-bold px-2 py-0.5 rounded-full">
                      مكتملة
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {formatDate(sale.timestamp)}
                  </p>
                  <p className="text-[11px] text-slate-500 font-semibold truncate max-w-xs">
                    {sale.items.map((it) => `${it.name} (${it.quantity})`).join(" ، ")}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-left">
                    <p className="text-xs text-slate-400 font-semibold">{totalItems} قطع</p>
                    <p className="text-sm font-black text-rose-600 font-mono tracking-tight">
                      {formatPrice(sale.totalAmount)}
                    </p>
                  </div>
                  {onDeleteSale && (
                    <button
                      id={`btn-row-delete-${sale.id}`}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSaleToDelete(sale);
                      }}
                      className="w-9 h-9 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center transition-colors cursor-pointer shrink-0 border border-rose-100/30"
                      title="حذف الفاتورة وإرجاع المواد"
                    >
                      <span className="material-symbols-outlined !text-lg">delete</span>
                    </button>
                  )}
                  <span className="material-symbols-outlined text-slate-300">chevron_left</span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Row-level delete confirmation modal */}
      <AnimatePresence>
        {saleToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setSaleToDelete(null)}></div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[32px] shadow-2xl p-6 relative flex flex-col z-10 border border-slate-100 text-right animate-in fade-in zoom-in-95 duration-200"
            >
              <div className="w-14 h-14 bg-rose-50 text-rose-500 flex items-center justify-center rounded-full mb-3">
                <span className="material-symbols-outlined !text-3xl">warning</span>
              </div>
              <h4 className="font-extrabold text-slate-800 text-base">حذف الفاتورة؟</h4>
              <p className="text-xs text-slate-500 mt-2 px-1 leading-relaxed font-medium">
                هل أنت متأكد من رغبتك في حذف الفاتورة رقم <span className="font-mono text-rose-600 font-bold">#{String(saleToDelete.orderNum).padStart(4, "0")}</span>؟ سيتم مسحها نهائياً وإرجاع الكميات المباعة إلى المخزون تلقائياً.
              </p>
              
              <div className="flex gap-2.5 w-full mt-6">
                <button
                  type="button"
                  onClick={() => {
                    if (onDeleteSale && saleToDelete) {
                      onDeleteSale(saleToDelete.id);
                      setSaleToDelete(null);
                    }
                  }}
                  className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all cursor-pointer shadow-md shadow-rose-200"
                >
                  تأكيد الحذف
                </button>
                <button
                  type="button"
                  onClick={() => setSaleToDelete(null)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Transaction Detailed Invoice Modal */}
      <AnimatePresence>
        {selectedSale && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            {/* Background overlay click */}
            <div className="absolute inset-0" onClick={() => setSelectedSale(null)}></div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-md rounded-[32px] shadow-2xl p-6 relative flex flex-col z-10 border border-slate-100"
            >
              {/* Receipt Visual Top Cut deco */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex gap-1 pointer-events-none">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="w-3 h-3 rounded-full bg-slate-900/40 backdrop-blur-xs"></div>
                ))}
              </div>

              {/* Header */}
              <div className="text-center pb-4 border-b border-dashed border-slate-200 mt-2">
                <div className="w-12 h-12 bg-rose-50 text-rose-500 flex items-center justify-center rounded-full mx-auto mb-2 shadow-inner">
                  <span className="material-symbols-outlined !text-2xl">spa</span>
                </div>
                <h3 className="font-extrabold text-slate-800 text-lg">{APP_CONFIG.storeName}</h3>
                <p className="text-[10px] text-slate-400 font-semibold mt-0.5">{APP_CONFIG.storeSubName}</p>
                <div className="mt-3 flex items-center justify-center gap-3">
                  <span className="text-xs bg-slate-100 text-slate-600 font-black px-3 py-1 rounded-full font-mono">
                    فاتورة #{String(selectedSale.orderNum).padStart(4, "0")}
                  </span>
                </div>
              </div>

              {/* Receipt Metadata */}
              <div className="py-3 text-xs text-slate-500 space-y-1.5 border-b border-slate-100">
                <div className="flex justify-between font-semibold">
                  <span>تاريخ البيع:</span>
                  <span className="text-slate-700 font-mono">{formatDate(selectedSale.timestamp)}</span>
                </div>
                <div className="flex justify-between font-semibold">
                  <span>نوع العملية:</span>
                  <span className="text-slate-700">بيع فوري (POS)</span>
                </div>
                <div className="flex justify-between font-semibold">
                  <span>حالة الدفع:</span>
                  <span className="text-emerald-600 font-bold">نقدي (تم القبض)</span>
                </div>
              </div>

              {/* Items Table */}
              <div className="flex-1 overflow-y-auto py-4 max-h-[25vh] space-y-3 no-scrollbar border-b border-dashed border-slate-200">
                {selectedSale.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between items-start text-xs">
                    <div className="min-w-0 flex-1 mr-1">
                      <p className="font-bold text-slate-800 truncate">{it.name}</p>
                      <p className="text-[10px] text-slate-400 font-semibold">{it.brand} × {it.quantity}</p>
                    </div>
                    <span className="font-bold text-slate-700 shrink-0 font-mono">
                      {formatPrice(it.total)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Total Calculation */}
              <div className="py-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold text-slate-800">المبلغ الإجمالي:</span>
                  <span className="text-lg font-black text-rose-600 font-mono tracking-tight">
                    {formatPrice(selectedSale.totalAmount)}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl flex flex-col items-center justify-center border border-slate-100 text-center gap-1">
                  <span className="material-symbols-outlined text-slate-400 !text-lg">cloud_done</span>
                  <p className="text-[10px] text-slate-500 font-bold leading-normal">
                    تمت المزامنة بنجاح في قاعدة بيانات الهاتف أوفلاين.
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2.5">
                <button
                  id="btn-close-receipt"
                  onClick={() => setSelectedSale(null)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                >
                  إغلاق الفاتورة
                </button>
                {onDeleteSale && (
                  <button
                    id="btn-delete-receipt"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="py-3 px-4 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 font-bold rounded-2xl text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                    title="حذف هذه الفاتورة وإرجاع المواد"
                  >
                    <span className="material-symbols-outlined !text-base">delete</span>
                    حذف
                  </button>
                )}
              </div>

              {/* Beautiful delete confirmation overlay inside the receipt card */}
              {showDeleteConfirm && (
                <div className="absolute inset-0 bg-white/98 rounded-[32px] p-6 flex flex-col items-center justify-center text-center z-20 animate-in fade-in zoom-in-95 duration-200">
                  <div className="w-14 h-14 bg-rose-50 text-rose-500 flex items-center justify-center rounded-full mb-3">
                    <span className="material-symbols-outlined !text-3xl">warning</span>
                  </div>
                  <h4 className="font-extrabold text-slate-800 text-base">حذف الفاتورة؟</h4>
                  <p className="text-xs text-slate-500 mt-2 px-4 leading-relaxed">
                    هل أنت متأكد من رغبتك في حذف هذه الفاتورة؟ سيتم مسح العملية نهائياً وإرجاع كميات المواد المباعة إلى المخزن.
                  </p>
                  
                  <div className="flex gap-2.5 w-full mt-6">
                    <button
                      type="button"
                      onClick={() => {
                        if (onDeleteSale && selectedSale) {
                          onDeleteSale(selectedSale.id);
                          setSelectedSale(null);
                          setShowDeleteConfirm(false);
                        }
                      }}
                      className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all cursor-pointer shadow-md shadow-rose-200"
                    >
                      تأكيد الحذف
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                    >
                      تراجع
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
