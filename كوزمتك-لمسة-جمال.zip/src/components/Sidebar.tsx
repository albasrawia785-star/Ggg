/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { 
  X, 
  LogOut, 
  ShoppingBag, 
  Box, 
  Tags, 
  History, 
  Clock, 
  BarChart2, 
  Settings as SettingsIcon,
  User,
  ShieldCheck,
  AlertCircle
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  currentUser: { username: string; role: "manager" | "cashier" } | null;
  cosmeticName: string;
  licenseStatus: {
    isValid: boolean;
    message: string;
    cosmeticName: string;
    licenseType: string;
    expireDate: string | null;
  };
  onLogout: () => void;
}

export default function Sidebar({
  isOpen,
  onClose,
  activeTab,
  onTabChange,
  currentUser,
  cosmeticName,
  licenseStatus,
  onLogout
}: SidebarProps) {
  if (!isOpen) return null;

  const menuItems = [
    { id: "sale", label: "شاشة البيع المباشر", icon: ShoppingBag, desc: "إصدار فواتير ومسح الباركود" },
    { id: "products", label: "مستودع البضائع", icon: Box, desc: "تعديل الكميات وإضافة منتجات" },
    { id: "categories", label: "تصنيفات البضاعة", icon: Tags, desc: "ترتيب وتنظيم الأقسام" },
    { id: "shifts", label: "ورديات الصندوق", icon: Clock, desc: "فتح وإغلاق اليوميات المالية" },
    { id: "reports", label: "التقارير والإحصائيات", icon: BarChart2, desc: "تحليل الأرباح ومستوى المبيعات" },
    { id: "settings", label: "إعدادات النظام", icon: SettingsIcon, desc: "التحكم بالنظام وإعادة الضبط" }
  ];

  return (
    <div className="absolute inset-0 z-50 overflow-hidden pointer-events-none" dir="rtl">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs pointer-events-auto cursor-pointer"
      />

      {/* Drawer Body */}
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 220 }}
        className="absolute top-0 right-0 bottom-0 w-80 max-w-full bg-[#FCFAF8] border-l border-[#EFE7E9] flex flex-col pointer-events-auto z-10 shadow-2xl"
      >
        {/* Header - Logo and Brand */}
        <div className="p-6 border-b border-[#EFE7E9] bg-white flex flex-col items-center text-center relative shrink-0">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-1.5 rounded-xl hover:bg-slate-50 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Elegant Custom-generated Beauty Logo */}
          <div className="w-20 h-20 bg-white border border-[#EFE7E9] rounded-2xl flex items-center justify-center shadow-xs overflow-hidden mb-3 mt-2">
            <img
              src="/src/assets/images/cosmetics_beauty_logo_1783807344564.jpg"
              alt="Custom Beauty Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <h3 className="font-extrabold text-sm text-[#252525] font-sans">
            {cosmeticName}
          </h3>
          <p className="text-[10px] text-[#7B0F3A] font-bold mt-1 tracking-wide uppercase">
            قائمة الإدارة والتحكم السريع
          </p>
        </div>

        {/* Current logged user badge */}
        <div className="mx-4 mt-4 px-4 py-3 bg-[#7B0F3A]/5 rounded-2xl border border-[#EFE7E9] flex items-center gap-3 flex-row justify-between text-right">
          <div className="text-right">
            <h4 className="text-xs font-extrabold text-[#252525]">
              {currentUser?.username || "مستخدم مجهول"}
            </h4>
            <p className="text-[9px] text-[#7B0F3A] font-bold mt-0.5">
              {currentUser?.role === "manager" ? "المدير العام (مشرف)" : "كاشير المبيعات"}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#EFE7E9] flex items-center justify-center text-[#7B0F3A] shrink-0">
            <User className="w-5 h-5" />
          </div>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1.5 no-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-item-${item.id}`}
                onClick={() => {
                  onTabChange(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 p-3 rounded-2xl transition-all cursor-pointer text-right group ${
                  isActive 
                    ? "bg-[#7B0F3A] text-white shadow-sm" 
                    : "hover:bg-[#7B0F3A]/5 text-slate-700 hover:text-[#7B0F3A]"
                }`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                  isActive ? "bg-white/10" : "bg-white border border-[#EFE7E9] group-hover:border-[#7B0F3A]/20"
                }`}>
                  <Icon className={`w-4.5 h-4.5 ${isActive ? "text-white" : "text-slate-500 group-hover:text-[#7B0F3A]"}`} />
                </div>
                
                <div className="flex-1">
                  <span className="text-xs font-extrabold block">
                    {item.label}
                  </span>
                  <span className={`text-[9px] font-medium block mt-0.5 ${
                    isActive ? "text-white/70" : "text-slate-400"
                  }`}>
                    {item.desc}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer - License status and Logout */}
        <div className="p-4 border-t border-[#EFE7E9] bg-white shrink-0 space-y-3">
          {/* License badge */}
          <div className={`flex items-center gap-2 p-2.5 rounded-xl border text-[10px] font-bold justify-end ${
            licenseStatus.isValid 
              ? "bg-emerald-50 border-emerald-100 text-emerald-700" 
              : "bg-rose-50 border-rose-100 text-rose-600"
          }`}>
            <span>{licenseStatus.message || (licenseStatus.isValid ? "الترخيص نشط وآمن" : "الترخيص منتهي")}</span>
            {licenseStatus.isValid ? (
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-500" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            )}
          </div>

          {/* Logout button */}
          <button
            id="sidebar-logout"
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="w-full h-11 border border-[#EFE7E9] hover:bg-rose-50 hover:border-rose-100 text-slate-600 hover:text-rose-600 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج من النظام
          </button>
        </div>
      </motion.div>
    </div>
  );
}
