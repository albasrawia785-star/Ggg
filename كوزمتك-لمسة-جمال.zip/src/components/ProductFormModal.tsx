/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product, Category } from "../types";
import { compressAndResizeImage } from "../database/sqlite";
import ProductImage from "./ProductImage";

interface ProductFormModalProps {
  product?: Product | null; // If null, we are adding. If object, we are editing.
  categories: Category[];
  onClose: () => void;
  onSave: (product: Product) => void;
  defaultLowStockThreshold: number;
}

export default function ProductFormModal({
  product,
  categories,
  onClose,
  onSave,
  defaultLowStockThreshold
}: ProductFormModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [price, setPrice] = useState<number | "">("");
  const [quantity, setQuantity] = useState<number | "">("");
  const [lowStockThreshold, setLowStockThreshold] = useState<number | "">("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [barcode, setBarcode] = useState("");
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (product) {
      setName(product.name);
      setBrand(product.brand);
      setCategoryId(product.categoryId);
      setPrice(product.price);
      setQuantity(product.quantity);
      setLowStockThreshold(product.lowStockThreshold);
      setDescription(product.description || "");
      setImage(product.image || "");
      setBarcode(product.barcode || "");
    } else {
      setName("");
      setBrand("");
      setCategoryId("");
      setPrice("");
      setQuantity("");
      setLowStockThreshold(defaultLowStockThreshold);
      setDescription("");
      setImage("");
      setBarcode("");
    }
    setErrors({});
  }, [product, categories, defaultLowStockThreshold]);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    try {
      const compressed = await compressAndResizeImage(file);
      setImage(compressed);
    } catch (error) {
      console.error("Error processing image:", error);
      alert("فشل في معالجة الصورة، يرجى تجربة صورة أخرى");
    } finally {
      setIsProcessingImage(false);
    }
  };

  const triggerGallery = () => {
    fileInputRef.current?.click();
  };

  const triggerCamera = () => {
    cameraInputRef.current?.click();
  };

  const handleRemoveImage = () => {
    setImage("");
  };

  const validate = (): boolean => {
    const tempErrors: { [key: string]: string } = {};

    if (!name.trim()) {
      tempErrors.name = "اسم المنتج مطلوب";
    }
    if (!categoryId) {
      tempErrors.categoryId = "يرجى اختيار تصنيف المنتج";
    }
    if (price === "" || Number(price) <= 0) {
      tempErrors.price = "السعر يجب أن يكون أكبر من صفر";
    }
    if (quantity === "" || Number(quantity) < 0 || !Number.isInteger(Number(quantity))) {
      tempErrors.quantity = "الكمية يجب أن تكون رقماً صحيحاً موجباً أو صفراً";
    }
    if (lowStockThreshold === "" || Number(lowStockThreshold) < 0 || !Number.isInteger(Number(lowStockThreshold))) {
      tempErrors.lowStockThreshold = "حد التنبيه يجب أن يكون رقماً صحيحاً موجباً أو صفراً";
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const savedProduct: Product = {
      id: product?.id || `prod_${Date.now()}`,
      name: name.trim(),
      brand: brand.trim() || "غير محدد",
      categoryId,
      price: Math.floor(Number(price)),
      quantity: Math.floor(Number(quantity)),
      lowStockThreshold: Math.floor(Number(lowStockThreshold)),
      description: description.trim(),
      image,
      barcode: barcode.trim(),
      createdAt: product?.createdAt || Date.now()
    };

    onSave(savedProduct);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
      {/* Background overlay click */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }}
        transition={{ type: "spring", damping: 25, stiffness: 350 }}
        className="relative bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] sm:max-h-[85vh] z-10"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-rose-500 !text-2xl">
              {product && product.id ? "edit_note" : "add_box"}
            </span>
            <h3 className="text-lg font-bold text-slate-800">
              {product && product.id ? "تعديل المنتج" : "إضافة منتج جديد"}
            </h3>
          </div>
          <button
            id="btn-close-form"
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center bg-slate-50 hover:bg-slate-100 text-slate-500 transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Form Body */}
        <form id="product-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Invisible file inputs */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageChange}
            accept="image/*"
            className="hidden"
          />
          <input
            type="file"
            ref={cameraInputRef}
            onChange={handleImageChange}
            accept="image/*"
            capture="environment"
            className="hidden"
          />

          {/* Product Image Area */}
          <div className="flex flex-col items-center gap-3">
            <label className="text-xs font-semibold text-slate-500 self-start">صورة المنتج</label>
            <div className="relative w-36 h-48 rounded-2xl overflow-hidden border-2 border-dashed border-slate-200 bg-slate-50 flex items-center justify-center group shadow-inner">
              {isProcessingImage ? (
                <div className="flex flex-col items-center gap-2">
                  <span className="animate-spin material-symbols-outlined text-rose-500 !text-3xl">sync</span>
                  <span className="text-[10px] text-slate-400">جارٍ الضغط...</span>
                </div>
              ) : image ? (
                <>
                  <ProductImage image={image} categoryId={categoryId} name={name} />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute top-2 right-2 w-8 h-8 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-md hover:bg-rose-700 transition-colors"
                  >
                    <span className="material-symbols-outlined !text-sm">delete</span>
                  </button>
                </>
              ) : (
                <div className="flex flex-col items-center text-center p-4">
                  <span className="material-symbols-outlined text-slate-300 !text-4xl mb-1">image_search</span>
                  <span className="text-[10px] text-slate-400">لا توجد صورة مخصصة</span>
                </div>
              )}
            </div>

            {/* Photo capture and Gallery selectors */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={triggerCamera}
                className="flex items-center gap-1.5 px-4 py-2 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-100 transition-colors text-xs font-bold shadow-sm"
              >
                <span className="material-symbols-outlined !text-lg">photo_camera</span>
                الكاميرا
              </button>
              <button
                type="button"
                onClick={triggerGallery}
                className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors text-xs font-bold shadow-sm"
              >
                <span className="material-symbols-outlined !text-lg">photo_library</span>
                المعرض
              </button>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            {/* Name */}
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">اسم المنتج <span className="text-rose-500">*</span></label>
              <input
                id="form-product-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: حمرة شفاه حمراء مات"
                className={`w-full px-4 py-3 rounded-xl border ${
                  errors.name ? "border-rose-400 bg-rose-50/20 focus:ring-rose-500 focus:border-rose-500" : "border-slate-200 focus:ring-rose-500 focus:border-rose-500"
                } focus:outline-none focus:ring-2 focus:ring-opacity-20 text-sm`}
              />
              {errors.name && <p className="text-rose-500 text-xs mt-1 font-semibold">{errors.name}</p>}
            </div>

            {/* Barcode */}
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">الباركود / رمز المنتج (اختياري)</label>
              <div className="relative">
                <input
                  id="form-product-barcode"
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  placeholder="مثال: 11111 أو الباركود العالمي للمنتج"
                  className="w-full pr-10 pl-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-sm font-mono text-right"
                  dir="ltr"
                />
                <span className="material-symbols-outlined absolute top-3 right-3 text-slate-400 !text-xl pointer-events-none">
                  barcode
                </span>
              </div>
            </div>

            {/* Brand & Category Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">العلامة التجارية (البراند)</label>
                <input
                  id="form-product-brand"
                  type="text"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="مثال: MAC"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">التصنيف <span className="text-rose-500">*</span></label>
                <select
                  id="form-product-category"
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-sm bg-white"
                >
                  <option value="">اختر التصنيف</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                {errors.categoryId && <p className="text-rose-500 text-xs mt-1 font-semibold">{errors.categoryId}</p>}
              </div>
            </div>

            {/* Price & Quantity Grid */}
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-slate-500 mb-1.5">سعر البيع (د.ع) <span className="text-rose-500">*</span></label>
                <div className="relative">
                  <input
                    id="form-product-price"
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value === "" ? "" : Number(e.target.value))}
                    placeholder="10,000"
                    className={`w-full pr-4 pl-12 py-3 rounded-xl border ${
                      errors.price ? "border-rose-400 focus:ring-rose-500 focus:border-rose-500" : "border-slate-200 focus:ring-rose-500 focus:border-rose-500"
                    } focus:outline-none focus:ring-2 focus:ring-opacity-20 text-sm [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
                  />
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <span className="text-xs font-semibold text-slate-400">د.ع</span>
                  </div>
                </div>
                {errors.price && <p className="text-rose-500 text-xs mt-1 font-semibold">{errors.price}</p>}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">الكمية <span className="text-rose-500">*</span></label>
                <input
                  id="form-product-quantity"
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="20"
                  className={`w-full px-3 py-3 rounded-xl border ${
                    errors.quantity ? "border-rose-400 focus:ring-rose-500 focus:border-rose-500" : "border-slate-200 focus:ring-rose-500 focus:border-rose-500"
                  } focus:outline-none focus:ring-2 focus:ring-opacity-20 text-sm [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
                />
                {errors.quantity && <p className="text-rose-500 text-xs mt-1 font-semibold">{errors.quantity}</p>}
              </div>
            </div>

            {/* Low Stock alert limit */}
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">حد تنبيه انخفاض المخزون <span className="text-rose-500">*</span></label>
              <input
                id="form-product-threshold"
                type="number"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value === "" ? "" : Number(e.target.value))}
                placeholder="5"
                className={`w-full px-4 py-3 rounded-xl border ${
                  errors.lowStockThreshold ? "border-rose-400 focus:ring-rose-500 focus:border-rose-500" : "border-slate-200 focus:ring-rose-500 focus:border-rose-500"
                } focus:outline-none focus:ring-2 focus:ring-opacity-20 text-sm [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
              />
              <p className="text-[10px] text-slate-400 mt-1 font-medium">سيعتبر المنتج "قليل المخزون" عندما تنخفض كميته لهذا الرقم أو أقل.</p>
              {errors.lowStockThreshold && <p className="text-rose-500 text-xs mt-1 font-semibold">{errors.lowStockThreshold}</p>}
            </div>

            {/* Description (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">وصف المنتج (اختياري)</label>
              <textarea
                id="form-product-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اكتب مواصفات المنتج وطريقة استخدامه..."
                rows={3}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-sm resize-none"
              ></textarea>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t border-slate-100">
            <button
              id="btn-submit-form"
              type="submit"
              className="flex-1 py-3.5 bg-rose-500 hover:bg-rose-600 active:scale-95 text-white rounded-2xl font-semibold shadow-md shadow-rose-200 transition-all text-sm flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined">save</span>
              حفظ المنتج
            </button>
            <button
              id="btn-cancel-form"
              type="button"
              onClick={onClose}
              className="flex-1 py-3.5 border border-slate-200 text-slate-600 rounded-2xl font-semibold hover:bg-slate-50 active:scale-95 transition-all text-sm"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>


    </div>
  );
}
