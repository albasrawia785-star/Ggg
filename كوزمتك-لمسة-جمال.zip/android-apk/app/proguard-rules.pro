# Proguard rules for LamsetJamalPOS WebView APK Wrapper

# Keep native methods and Android entrypoints
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep webview clients from being stripped or renamed
-keep class android.webkit.** { *; }

# Keep App entry activity
-keep class com.lamsetjamal.pos.MainActivity { *; }

# General optimizations
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontpreverify
-verbose
