@rem Windows Batch script for executing Gradle build on Windows
@rem Auto-downloads gradle-wrapper.jar if missing

@echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.\

if not exist "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" (
    echo ------------------------------------------------------------
    echo gradle-wrapper.jar not found! Bootstrapping download...
    echo ------------------------------------------------------------
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('https://raw.githubusercontent.com/gradle/gradle/v8.4/gradle/wrapper/gradle-wrapper.jar', '%DIRNAME%gradle\wrapper\gradle-wrapper.jar')"
    echo gradle-wrapper.jar downloaded successfully!
)

@rem Find Java
if not "%JAVA_HOME%" == "" (
    set "JAVACMD=%JAVA_HOME%\bin\java.exe"
) else (
    set JAVACMD=java.exe
)

@rem Execute
"%JAVACMD%" -classpath "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
endlocal
