package io.ionic.starter // TODO: Replace with your actual application package name (e.g. com.yourdomain.app)

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.EdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // 1. Enable Android Edge-to-Edge using the latest AndroidX APIs.
        // This ensures the window is laid out behind system bars by default on all supported Android versions.
        EdgeToEdge.enable(this)
        
        super.onCreate(savedInstanceState)
        
        // 2. Adjust decor fits system windows to true so that layout stays within the system bars (no drawing behind them)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        // 3. Ensure the layout handles display cutouts (notches) correctly.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode = 
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
    }
}
