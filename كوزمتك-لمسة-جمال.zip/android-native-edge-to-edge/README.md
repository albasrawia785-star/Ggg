# Capacitor Android True Edge-to-Edge Fullscreen Integration Guide

This guide describes how to achieve a **true edge-to-edge immersive fullscreen mode** on modern Android devices (including compatibility with Android 12, 13, 14, 15, and 16) inside a Capacitor application. 

It satisfies all requirements, including extending the WebView behind the status/navigation bar, notch (display cutout) support, immersive sticky focus re-hiding, and avoiding the black bottom navigation area.

---

## 📂 Source Files Provided

Inside this `/android-native-edge-to-edge` directory, you will find:
1. **`MainActivity.kt`** (Kotlin) & **`MainActivity.java`** (Java) — Full Native controllers depending on what language your Capacitor android app uses.
2. **`styles.xml`** — Theme resources with transparency, shortEdge cutout modes, and statusbar configurations.
3. **`AndroidManifest.xml`** — Correct layout metadata referencing `AppTheme`.

---

## 🛠️ Integration Steps

### Step 1: Add/Update dependencies in your `android/app/build.gradle`
To use modern `androidx.activity.EdgeToEdge` APIs, you need to ensure your AndroidX dependencies are up-to-date. In `android/app/build.gradle`, add or update the following dependencies:

```groovy
dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    implementation "com.getcapacitor:android:$capacitorVersion"
    
    // Core AndroidX Activity & Core libraries for modern EdgeToEdge APIs
    implementation "androidx.activity:activity:1.8.0" // or newer
    implementation "androidx.core:core:1.12.0" // or newer
    
    // If you are using Kotlin, also ensure core-ktx is included:
    implementation "androidx.core:core-ktx:1.12.0"
}
```

---

### Step 2: Replace or modify your `MainActivity` file
Depending on whether your app is written in **Kotlin** or **Java**:

* **For Kotlin**: Copy the contents of `MainActivity.kt` into `android/app/src/main/java/[your-package-name]/MainActivity.kt`.
* **For Java**: Copy the contents of `MainActivity.java` into `android/app/src/main/java/[your-package-name]/MainActivity.java`.

> ⚠️ **Important**: Make sure to replace the first line `package io.ionic.starter` with your actual application package ID (which can be found at the top of your existing files or inside your `/android/app/build.gradle` file under `defaultConfig.applicationId`).

---

### Step 3: Configure styles/themes (`styles.xml`)
Replace the contents of your `android/app/src/main/res/values/styles.xml` with our custom theme. 
This configuration:
* Sets status and navigation bars to transparent.
* Removes native shadows/borders.
* Employs `shortEdges` rendering mode for display cutouts (preventing black margin bars around device camera notches).

---

### Step 4: Bind theme to your `AndroidManifest.xml`
Ensure your activity's theme points to `@style/AppTheme`. Open `android/app/src/main/AndroidManifest.xml` and make sure both `<application>` and the main launcher `<activity>` tag include the theme attribute:

```xml
<application
    ...
    android:theme="@style/AppTheme">

    <activity
        android:name=".MainActivity"
        android:theme="@style/AppTheme"
        ... >
```

---

## 💡 How It Works Under the Hood

### 1. Webview Extension & Transparency
By calling `EdgeToEdge.enable(this)` prior to calling `super.onCreate()`, we enable the system to treat the app boundaries as full physical screen pixels. We then explicitly call `WindowCompat.setDecorFitsSystemWindows(window, false)` which commands the layout view containing the Capacitor WebView to ignore native system padding bounds.

### 2. Immersive Sticky Focus Recovery (`onWindowFocusChanged`)
In immersive modes, if a user swipes down from the top to see notifications or opens the system navigation, the system bars temporarily display. When the user returns to the app, standard implementations fail to re-hide them automatically, leaving empty black or white bars. 
By overriding `onWindowFocusChanged(hasFocus: Boolean)`, our native code catches focus regain events and forces the system bars back to the hidden transient state.

### 3. Native Notch & Cutout Handling (`shortEdges`)
Normally, devices with camera cutouts (notches) restrict the WebView container to a rectangle starting below the cutout. Setting the attribute `android:windowLayoutInDisplayCutoutMode` to `shortEdges` (both in Java/Kotlin programmatically and via `styles.xml` themes) forces the WebView container to stretch behind the notch, enabling gorgeous full-bleed content.
